<?php
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
require_once "connect.php";
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
    echo "<center>You should sign in to access <br>";
    //echo "<a href=$admin_url><b>LOGIN</b></a></center>";
} else { ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="css/animations.css">  
    <link rel="stylesheet" href="css/main.css">  
	<link rel="stylesheet" href="css/admin.css">
    <script src="js/javascript.js"></script>
	<title>Dashboard Secretariat</title>
    <style>
        .dashbord-tables{
            animation: transitionIn-Y-over 0.5s;
        }
        .filter-container{
            animation: transitionIn-Y-bottom  0.5s;
        }
        .sub-table{
            animation: transitionIn-Y-bottom 0.5s;
        }
    </style>
</head>
<body>
    <div class="container">
	<div class="menu">
            <table class="menu-container" border="0">
                <tr>
                    <td style="padding:10px" colspan="2">
                        <table border="0" class="profile-container">
                            <tr>
                                <td width="30%" style="padding-left:20px" >
                                    <img src="img/sec.png" alt="" width="100%" style="border-radius:50%">
                                </td>
                                <td style="padding:0px;margin:0px;">
                                    <p class="profile-title">Secretariat</p>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <a href="logout.php" ><input type="button" value="Log out" class="logout-btn btn-primary-soft btn"></a>
                                </td>
                            </tr>
                    </table>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn menu-icon-doctor">
                        <a href="pageAdmin.php?modele=patient" name="menu" class="non-style-link-menu"><div><p class="menu-text">Patient</p></a></div>
                    </td>
                </tr>
                
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-session">
                    <a href="pageAdmin.php?modele=specialite" name="rdv" class="non-style-link-menu"><div><p class="menu-text">Rendez-vous</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-appoinment">
                        <a href="pageAdmin.php?modele=synthese" class="non-style-link-menu"><div><p class="menu-text">Consulter fiche patient</p></a></div>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-settings">
                        <a href="settings.php" class="non-style-link-menu"><div><p class="menu-text">Settings</p></a></div>
                    </td>
                </tr>


                
                
            </table>
            
        </div>
        <div class="dash-body">
            <table border="0" width="100%" style=" border-spacing: 0;margin:0;padding:0;margin-top:25px; ">
    <tr >
                    <td width="13%">
                        <a href="pageAdmin.php?modele=patient" ><button  class="login-btn btn-primary-soft btn btn-icon-back"  style="padding-top:11px;padding-bottom:11px;margin-left:20px;width:125px"><font class="tn-in-text">Back</font></button></a>
                    </td>
                    <td>
                        
                        <form action="pageAdmin.php?modele=patient" method="post" class="header-search">

                            <input type="search" name="search" class="input-text header-searchbar" placeholder="Search Doctor name or Email" list="patient">&nbsp;&nbsp;
                            
                            <?php
                                echo '<datalist id="patient">';
                                $querySearch= "select  nomPatient,prenomPatient from  patient;";
                                $resultat=$connection->query($querySearch);
                                $resultat->setFetchMode(PDO::FETCH_OBJ);
                                while($ligne = $resultat->fetch()){
                                    for ($i=0; $i < $ligne; $i++) { 
                                        $np=$ligne->nomPatient;
                                        $pp=$ligne->prenomPatient;
                                        echo "<option value='$np'><br/>";
                                        echo "<option value='$pp'><br/>";
                                    };
                                };

                            echo ' </datalist>';
?>
                            
                       
                            <input type="Submit" value="Search" class="login-btn btn-primary btn" style="padding-left: 25px;padding-right: 25px;padding-top: 10px;padding-bottom: 10px;">
                        
                        </form>
                        
                    </td>
                    <td width="15%">
                        <p style="font-size: 14px;color: rgb(119, 119, 119);padding: 0;margin: 0;text-align: right;">
                            Today's Date
                        </p>
                        <p class="heading-sub12" style="padding: 0;margin: 0;">
                            <?php 
                        date_default_timezone_set('Europe/France');

                        $date = date('Y-m-d');
                        echo $date;
                        ?>
                        </p>
                    </td>
                    <td width="10%">
                        <button  class="btn-label"  style="display: flex;justify-content: center;align-items: center;"><img src="img/calendar.svg" width="100%"></button>
                    </td>


                </tr>
               
                <tr>
                    <td colspan="4" style="padding-top:10px;">
                        <p class="heading-main12" style="margin-left: 45px;font-size:18px;color:rgb(49, 49, 49)">Dashboard</p>
                    </td>
                    
                </tr>
                <?php
                    if($_POST){
                        $keyword=$_POST["search"];
                        
                        $sqlmain= "select * from patient where nomPatient='$keyword' or prenomPatient='$keyword' or nomPatient like '$keyword%' or prenomPatient like '%$keyword' or nomPatient like '%$keyword%'";
                    }else{
                        $sqlmain= "select * from patient order by idPatient desc";

                    }



                ?>
        <tr>
        <td colspan="4">
            <center>
                <div class="abc scroll">
                        <table width="93%" class="sub-table scrolldown"  style="border-spacing:0;">
                <?php
                if($_GET['modele'] == 'patient'){
                    require_once "modele/Secretariat/patient/listPatient.php";
                }elseif ($_GET['modele'] == 'ajouterPatient') {
                    require_once "modele/Secretariat/patient/formAjouter.php";
                }elseif ($_GET['modele'] == 'modifierPatient') {
                    require_once "modele/Secretariat/patient/formModif.php";
                }elseif ($_GET['modele'] == 'depotPatient') {
                    require_once "modele/Secretariat/patient/formDepot.php";
                }elseif ($_GET['modele'] == 'specialite') {
                    require_once "modele/Secretariat/rdv/specialite.php";
                }elseif ($_GET['modele'] == 'rechercheMedecin') {
                    require_once "modele/Secretariat/rdv/rechercheMedecin.php";
                }elseif ($_GET['modele'] == 'prendreRDV') {
                    require_once "modele/Secretariat/rdv/prendreRDV.php";
                }elseif ($_GET['modele'] == 'rdvMedecin') {
                    require_once "modele/Secretariat/rdv/rdvMedecin.php";
                }elseif ($_GET['modele'] == 'validerDate') {
                    require_once "modele/Secretariat/rdv/validerDate.php";
                }elseif ($_GET['modele'] == 'validerRDV') {
                    require_once "modele/Secretariat/rdv/validerRDV.php";
                }elseif ($_GET['modele'] == 'synthese') {
                    require_once "modele/Secretariat/synthese/rdvPatient.php";
                }elseif ($_GET['modele'] == 'affichePatient') {
                    require_once "modele/Secretariat/synthese/affichePatient.php";
                }elseif ($_GET['modele'] == 'paiementPatient') {
                    require_once "modele/Secretariat/synthese/payer.php";
                }
                else{
                    require_once "pageAdmin.php";
                }
                ?>
                </table>
            </div>
            </center>
            </td>
            </tr>
            </table>
    </div>
</div>



</body>
</html>
<?php } ?>
