<?php
$url ="http://localhost/workspace/Programmation_web/projet_clinique_noMVC/";
?>