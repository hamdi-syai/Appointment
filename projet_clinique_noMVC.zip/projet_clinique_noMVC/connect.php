<?php
define("SERVEUR", "localhost");
define("USER", "root");
define("PASSWORD", "");
define("BDD", "projet_clinique");

/* Attempt to connect to MySQL database */
try{
    $connection=new PDO('mysql:host='.SERVEUR.';dbname='.BDD,USER,PASSWORD);
	$connection->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
	$connection->query("SET NAMES UTF8");
} catch(PDOException $e){
    die("ERROR: Could not connect. " . $e->getMessage());
}
?>