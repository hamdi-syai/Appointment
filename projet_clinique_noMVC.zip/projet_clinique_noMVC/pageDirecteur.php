<?php
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
require_once "connect.php";
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
    echo "<center>Untuk mengakses modul, Anda harus login <br>";
    //echo "<a href=$admin_url><b>LOGIN</b></a></center>";
} else { ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="css/animations.css">  
    <link rel="stylesheet" href="css/main.css">  
	<link rel="stylesheet" href="css/admin.css">
    <script src="js/javascript.js"></script>
	<title>Page Directeur</title>
	<style>
        .dashbord-tables{
            animation: transitionIn-Y-over 0.5s;
        }
        .filter-container{
            animation: transitionIn-Y-bottom  0.5s;
        }
        .sub-table{
            animation: transitionIn-Y-bottom 0.5s;
        }
    </style>
</head>
<body>
<div class="container">
	<div class="menu">
            <table class="menu-container" border="0">
                <tr>
                    <td style="padding:10px" colspan="2">
                        <table border="0" class="profile-container">
                            <tr>
                                <td width="30%" style="padding-left:20px" >
                                    <img src="img/dir.png" alt="" width="100%" style="border-radius:50%">
                                </td>
                                <td style="padding:0px;margin:0px;">
                                    <p class="profile-title">Directeur</p>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <a href="logout.php" ><input type="button" value="Log out" class="logout-btn btn-primary-soft btn"></a>
                                </td>
                            </tr>
                    </table>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn menu-icon-doctor">
					<a href="pageDirecteur.php?modele=employeur" name="salarie" class="non-style-link-menu"><div><p class="menu-text">Gestion salaries</p></a></div>
                    </td>
                </tr>
                
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-session">
                    <a href="pageDirecteur.php?modele=listefourni" name="motif" class="non-style-link-menu"><div><p class="menu-text">Gestion Motif</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-session">
                    <a href="pageDirecteur.php?modele=listepieces" name="pieces" class="non-style-link-menu"><div><p class="menu-text">Gestion Pieces</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-session">
                    <a href="pageDirecteur.php?modele=listeconsigne" name="pieces" class="non-style-link-menu"><div><p class="menu-text">Gestion Consigne</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-appoinment">
                        <a href="pageDirecteur.php?modele=listespecialite" class="non-style-link-menu"><div><p class="menu-text">Specialite medecin</p></a></div>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-settings">
                        <a href="settings.php" class="non-style-link-menu"><div><p class="menu-text">Settings</p></a></div>
                    </td>
                </tr>                
            </table>
	</div>
    <div class="dash-body">
            <table border="0" width="100%" style=" border-spacing: 0;margin:0;padding:0;margin-top:25px; ">
    <tr >
                    <td width="13%">
                        <a href="pageDirecteur.php?modele=employeur" ><button  class="login-btn btn-primary-soft btn btn-icon-back"  style="padding-top:11px;padding-bottom:11px;margin-left:20px;width:125px"><font class="tn-in-text">Back</font></button></a>
                    </td>
                    <td>
                        
                        <form action="" method="post" class="header-search">

                            <input type="search" name="search" class="input-text header-searchbar" placeholder="Search Doctor name or Email" list="doctors">&nbsp;&nbsp;
                            
                            <?php
                            echo '<datalist id="patient">';
                            $querySearch= "select  nomPersonnel,prenomPersonnel from  personnel;";
                            $resultat=$connection->query($querySearch);
                            $resultat->setFetchMode(PDO::FETCH_OBJ);
                            while($ligne = $resultat->fetch()){
                                for ($i=0; $i < $ligne; $i++) { 
                                    $np=$ligne->nomPersonnel;
                                    $pp=$ligne->prenomPersonnel;
                                    echo "<option value='$np'><br/>";
                                    echo "<option value='$pp'><br/>";
                                };
                            };

                        echo ' </datalist>';
?>
                            
                       
                            <input type="Submit" value="Search" class="login-btn btn-primary btn" style="padding-left: 25px;padding-right: 25px;padding-top: 10px;padding-bottom: 10px;">
                        
                        </form>
                        
                    </td>
                    <td width="15%">
                        <p style="font-size: 14px;color: rgb(119, 119, 119);padding: 0;margin: 0;text-align: right;">
                            Today's Date
                        </p>
                        <p class="heading-sub12" style="padding: 0;margin: 0;">
                            <?php 
                        date_default_timezone_set('Europe/France');

                        $date = date('Y-m-d');
                        echo $date;
                        ?>
                        </p>
                    </td>
                    <td width="10%">
                        <button  class="btn-label"  style="display: flex;justify-content: center;align-items: center;"><img src="img/calendar.svg" width="100%"></button>
                    </td>


                </tr>
               
                <tr>
                    <td colspan="4" style="padding-top:10px;">
                        <p class="heading-main12" style="margin-left: 45px;font-size:18px;color:rgb(49, 49, 49)">Dashboard</p>
                    </td>
                    
                </tr>
                <?php
                    if($_POST){
                        $keyword=$_POST["search"];
                        
                        $sqlmain= "select * from personnel where nomPersonnel='$keyword' or prenomPersonnel='$keyword' or nomPersonnel like '$keyword%' or prenomPersonnel like '%$keyword' or nomPersonnel like '%$keyword%'";
                    }else{
                        $sqlmain= "select * from personnel order by idPatient desc";

                    }



                ?>
        <tr>
        <td colspan="4">
            <center>
                <div class="abc scroll">
                        <table width="93%" class="sub-table scrolldown"  style="border-spacing:0;">
						<?php

						if($_GET['modele'] == 'employeur'){
							require_once "modele/Directeur/employeur/listEmployeur.php";
						}elseif ($_GET['modele'] == 'ajouterPersonnel') {
							require_once "modele/Directeur/employeur/formAjouter.php";
						}elseif ($_GET['modele'] == 'modifierPersonnel') {
							require_once "modele/Directeur/employeur/formModif.php";

						}elseif ($_GET['modele'] == 'listefourni') {
							require_once "modele/Directeur/Motif/listefourni.php";
						}elseif ($_GET['modele'] == 'ajouterMotif') {
							require_once "modele/Directeur/Motif/ajouterMotif.php";
						}elseif ($_GET['modele'] == 'modifierMotif') {
							require_once "modele/Directeur/Motif/modifMotif.php";

						}elseif ($_GET['modele'] == 'listepieces') {
                            require_once "modele/Directeur/pieces/listepieces.php";
                        }elseif ($_GET['modele'] == 'ajouterpieces') {
                            require_once "modele/Directeur/pieces/ajouterpieces.php";
                        }elseif ($_GET['modele'] == 'modifierPieces') {
                            require_once "modele/Directeur/pieces/modifpieces.php";

                        }elseif ($_GET['modele'] == 'listeconsigne') {
                            require_once "modele/Directeur/consigne/listeconsigne.php";
                        }elseif ($_GET['modele'] == 'ajouterconsigne') {
                            require_once "modele/Directeur/consigne/ajouterconsigne.php";
                        }elseif ($_GET['modele'] == 'modifierconsigne') {
                            require_once "modele/Directeur/consigne/modifconsigne.php";

                        }elseif ($_GET['modele'] == 'listespecialite') {
                            require_once "modele/Directeur/specialite/listespecialite.php";
                        }elseif ($_GET['modele'] == 'ajouterspecialite') {
                            require_once "modele/Directeur/specialite/ajouterspecialite.php";
                        }elseif ($_GET['modele'] == 'modifierspecialite') {
                            require_once "modele/Directeur/specialite/modifspecialite.php";
                        } else{
							require_once "pageDirecteur.php";
						}
						?>
                </table>
            </div>
            </center>
            </td>
            </tr>
        </table>
    </div>
</div>

</body>
</html>
<?php } ?>
