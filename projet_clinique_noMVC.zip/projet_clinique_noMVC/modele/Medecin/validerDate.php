<?php   
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);
if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
    echo "<center>Untuk mengakses modul, Anda harus login <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else { ?>
    <tbody>
        
        <?php
        /* for ($i = 0; $i < $_POST['session']; $i++) { 
            $rawdate = isset($_POST['daterdv'.$i]) ? htmlentities($_POST['daterdv'.$i]) : '';
            if ($rawdate) {
                $day = date('Y-m-d H:i', strtotime($rawdate));
                $idmed = $_POST['idmed'.$i];
                $query = "insert into tacheadmin (datetache, idPersonnel) values ('$day', '$idmed')";
                $resultat = $connection->query($query);
                echo '<h1>Vous avez un rendez-vous le '.$day.'</h1>';
            }
        }
        $resultat->closeCursor(); */
        
            //require_once "connect.php";
            $idmedecin = $_POST['idmed'];
            $query = "SELECT * FROM personnel WHERE idPersonnel = '$idmedecin'";
            $result = $connection->query($query);
            $row = $result->setFetchMode(PDO::FETCH_OBJ);
            echo $idmedecin;
         for ($i=0; $i < $_POST['session']; $i++) { 
            $date = $_POST ['daterdv'.$i];
            echo $date.'##';
            
            // Check if the idPersonnel exists in the personnel table
            /* $query = "SELECT * FROM personnel WHERE idPersonnel = '$idmed'";
            $result = $connection->query($query);
            $row = $result->fetch(PDO::FETCH_ASSOC); */
            //$ligne=$row->fetch();
            
            if ($row==true) {
            /* $idmed = $_POST['idmed'];
            echo $idmed; */
            // The idPersonnel exists in the personnel table, insert the data into tacheadmin
            //$rawdate = isset($_POST['daterdv'.$i]) ? htmlentities($_POST['daterdv'.$i]) : '';
            /* $rawdate = htmlentities($_POST['daterdv'.$i]); */
            $rawdate = isset($_POST['daterdv'.$i]) ? htmlentities($_POST['daterdv'.$i]) : '';
            $day = date('Y-m-d H:i', strtotime($rawdate));
            $query="INSERT INTO `tacheadmin`(`dateTache`, `idpersonnel`) VALUES ('$day$i', '$idmedecin')";
            //$query = "INSERT INTO tacheadmin (dateTache, idPersonnel) VALUES ('$day$i', '$idmed$i')";
            $resultat = $connection->query($query);
            echo'<h1></h1>Vous avez avec'.$idmedecin.' un rendez-vous le '.$day.'</form>';
            $resultat->closeCursor(); 
            } else {
            // The idPersonnel does not exist in the personnel table, handle the error accordingly
            }
            echo  $idmedecin .'--'. $day;

            /* $rawdate = isset($_POST['daterdv'.$i]) ? htmlentities($_POST['daterdv'.$i]) : '';
            //$rawdate = htmlentities($_POST['daterdv'.$i]);
            $timestamp = strtotime($rawdate);
            $day = date('Y-m-d H:i', $timestamp);
            /* $rawdate = isset($_POST['daterdv'.$i]) ? htmlentities($_POST['daterdv'.$i]) : '';
            $day = date('Y-m-d H:i', ($rawdate));
            $idmed = $_POST['idmed'.$i];
            $query="insert into tacheadmin (datetache, idpersonnel) values('$day', '$idmed')";
            $resultat = $connection->query($query); */
        }
        
       /*  
        $numsecu = $_POST['numsecu'];
        $queryTache="SELECT * FROM tacheadmin INNER JOIN personnel ON tacheadmin.idPersonnel=personnel.idPersonnel WHERE personnel.idPersonnel ='$idmed' and dateTache = '$day'";
        $resultat=$connection->query($queryTache);
        $resultat->setFetchMode(PDO::FETCH_OBJ);
        $ligne=$resultat->fetch();
        if ($ligne == true) { ?>
            <h1>le medecin ou la date de RDV n'est pas disponible!</h1></br>
            <h2>essaye de change le medecin ou la date!</h2>
        <?php }else {
            
            //require_once "../../../projet_clinique_noMVC/config.php";
            //require_once "../../../projet_clinique_noMVC/connect.php";
               /*  require_once "connect.php";
                $rawdate = htmlentities($_POST['day2']);
                $day = date('Y-m-d H:i', strtotime($rawdate));
                //$heure = $_POST['hours'];
                $idmed = $_POST['idmed'];
                $numsecu = $_POST['numsecu']; */
               /*  $query="insert into rdv (dateRDV, nss, idPersonnel) values('$day', $numsecu, $idmed)";
                $resultat = $connection->query($query);       
                //echo'bravo';         
               
    
                
     } */
        }
        ?>

    </tbody>
    
