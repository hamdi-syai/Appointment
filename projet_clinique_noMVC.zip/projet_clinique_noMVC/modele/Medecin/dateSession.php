<?php   
session_start();

if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
    echo "<center>Untuk mengakses modul, Anda harus login <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else { ?>


	<thead>
		<tr>
            <th  class="table-headin">Nom Medecin</th>
            <th  class="table-headin">Date de Session</th>
            <!-- <th class="table-headin">Prenom </th>
            <th class="table-headin">Poste </th> -->
            <!-- <th class="table-headin">Specialite </th> -->
            <th class="table-headin">Action</th>
        </tr>
	</thead>
	<tbody id="f3">
		
			
			<tr>
				<form method="post" id="f1">
				<?php
        //require_once "../../../projet_clinique_noMVC/config.php";
        //require_once "../../../projet_clinique_noMVC/connect.php";
        	require_once "connect.php";
			/* $rawdate = htmlentities($_POST['daterdv']);
			$dayrdv = date('Y-m-d\TH:i', strtotime($rawdate));
			//$date = $_POST['day'];
			//$heure = $_POST['heure'];*/
			$idmed = $_POST['idmed'];
			$nommedecin = $_POST['nommedecin']; 
			//<input type="hidden" name="idmed" value="'.$date.'"/><input type="hidden" name="idmed" value="'.$heure.'"/><input type="hidden" name="idmed" value="'.$idmed.'"/>
			//$medecin = $_POST['mdcn'];
			$query="select * from personnel where idPersonnel='$idmed'";
			$resultat=$connection->query($query);
			$resultat->setFetchMode(PDO::FETCH_OBJ);
			$ligne=$resultat->fetch();
			?>
                    <td style="text-align:center;" >
						<label class="label-td">Nombre de Session : </label>
						<input type="hidden" class="input-text"  style="text-align:center;" name="idmed" value="<?php echo $ligne->idPersonnel; ?>" readonly/>
						<input type="hidden" class="input-text"  style="text-align:center;" name="nommedecin" value="<?php echo $ligne->nomPersonnel;?>" readonly/>
					</td>
                    <td style="text-align:center;">
                        <input type="text" class="input-text" name="session"/>
                    </td>
                    <td style="text-align:center;">
                    <input type="button" value="Execute" class="btn-primary-soft btn button-icon btn-edit tn-in-text"  style="padding-left: 40px;padding-top: 12px;padding-bottom: 12px;margin-top: 10px;" onclick="nbSession()"/>
                    </td>
					
					<!-- <td>
						<div style="display:flex;justify-content: center;">
                            <input type="submit" class="btn-primary-soft btn button-icon btn-edit tn-in-text"  style="padding-left: 40px;padding-top: 12px;padding-bottom: 12px;margin-top: 10px;" name="validerrdv" value="Valider" formaction="pageAdmin.php?modele=validerDate"/>
                        </div>
					</td> -->
					
			</tr>
			
			
            
	</tbody>
			<tr id="f4">
				<td>
					<div style="display:flex;justify-content: center;">
                        <input type="submit" class="btn-primary-soft btn button-icon btn-edit tn-in-text"  style="padding-left: 40px;padding-top: 12px;padding-bottom: 12px;margin-top: 10px;" name="validerrdv" value="Valider" formaction="pageMedecin.php?modele=validerDate"/>
                    </div>
				</td>
			</tr>
			</form>
            <script src="js/javascript.js">
                
            </script>
<?php
} ?>
