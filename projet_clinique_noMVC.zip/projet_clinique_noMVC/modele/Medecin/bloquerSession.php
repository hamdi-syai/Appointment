<?php   
 //session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
    echo "<center>Untuk mengakses modul, Anda harus login <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else { ?>
<style>
        .popup{
            animation: transitionIn-Y-bottom 0.5s;
        }
        .sub-table{
            animation: transitionIn-Y-bottom 0.5s;
        }
</style><?php   

if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
    echo "<center>Untuk mengakses modul, Anda harus login <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else { ?>       
        
        <center>
		<table width="80%" border="0">
            <tr>
                <td class="label-td" colspan="2"></td>
            </tr>
                <tr>
                    <td>
                        <p style="padding: 0;margin: 0;text-align: left;font-size: 25px;font-weight: 500;">Choisir votre Identifiant :</p><br><br>
                    </td>
                </tr>
				<tr>
				<form method="post">
					<td class="label-td" colspan="2">
                        <label for="name" class="form-label">Nom medecin : </label>
                    </td>
				</tr>
				<tr>
                    <td class="label-td" colspan="2">
                    <select name="idmed" class="box">
					<?php
                    require_once "connect.php";
                    $query="SELECT * FROM personnel where idCategorie='2'";
                    $resultat=$connection->query($query);
                    $resultat->setFetchMode(PDO::FETCH_OBJ);
						while($ligne=$resultat->fetch()){
						?>
						<option value="<?php echo $ligne->idPersonnel; ?>"><?php echo $ligne->nomPersonnel;?> <?php echo $ligne->prenomPersonnel;?></option>
						
						<?php }
						$resultat->closeCursor();
						
						?>
                    </select>
                    </td>  
                </tr>
				<tr>
                    <td colspan="2">                    
                        <input type="submit" formaction="pageMedecin.php?modele=dateSession" value="Valider Medecin" class="login-btn btn-primary btn">
                    </td>
                </tr>

				</form>
                </table>
				
</center>

<?php } } ?>
