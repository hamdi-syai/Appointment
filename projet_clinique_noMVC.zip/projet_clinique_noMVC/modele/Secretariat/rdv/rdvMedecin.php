<?php   
session_start();

if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
    echo "<center>Untuk mengakses modul, Anda harus login <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else { ?>


	<thead>
		<tr>
            <th colspan="2" class="table-headin">Saisir le numéro de Sécurité Sociale</th>
            <!-- <th class="table-headin">Prenom </th>
            <th class="table-headin">Poste </th> -->
            <!-- <th class="table-headin">Specialite </th> -->
            <th class="table-headin">Action</th>
        </tr>
	</thead>
	<tbody>
		<?php
        //require_once "../../../projet_clinique_noMVC/config.php";
        //require_once "../../../projet_clinique_noMVC/connect.php";
        	require_once "connect.php";
			$rawdate = htmlentities($_POST['daterdv']);
			$dayrdv = date('Y-m-d\TH:i', strtotime($rawdate));
			//$date = $_POST['day'];
			//$heure = $_POST['heure'];
			$idmed = $_POST['idmed'];
			$nommedecin = $_POST['nommedecin']; 
			//<input type="hidden" name="idmed" value="'.$date.'"/><input type="hidden" name="idmed" value="'.$heure.'"/><input type="hidden" name="idmed" value="'.$idmed.'"/>
			//$medecin = $_POST['mdcn'];
			$query="select * from rdv inner join  personnel on rdv.idPersonnel=personnel.idPersonnel";
			$resultat=$connection->query($query);
			$resultat->setFetchMode(PDO::FETCH_OBJ);
			$ligne=$resultat->fetch();
			?>
			<tr>
				<form method="post">
					<td style="text-align:center;" >
						<label class="label-td">Numéro de Securité Sociale : </label>
					</td>
					<td>
						<div>
							<input type="text" name="numsecu" class="input-text" size="15" minlength="15" maxlength="15" required/>
							<input type="hidden" name="day1" value="<?php echo $dayrdv ?>" readonly/>
							<input type="hidden" name="idmed" value="<?php echo $idmed ?>"readonly/>
							<input type="hidden" name="nommedecin" value="<?php echo $nommedecin ?>" readonly/>
						</div>
					</td>
					<td>
						<div style="display:flex;justify-content: center;">
                            <input type="submit" class="btn-primary-soft btn button-icon btn-edit tn-in-text"  style="padding-left: 40px;padding-top: 12px;padding-bottom: 12px;margin-top: 10px;" name="validerrdv" value="Valider" formaction="pageAdmin.php?modele=validerDate"/>
                        </div>
					</td>
				</form>
			</tr>
	</tbody>
<?php
} ?>
