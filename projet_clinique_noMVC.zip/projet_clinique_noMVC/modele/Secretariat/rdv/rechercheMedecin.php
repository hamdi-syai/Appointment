<?php   
session_start();

if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
    echo "<center>Untuk mengakses modul, Anda harus login <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else { ?>       
        
        <thead>
        <tr>
            <th class="table-headin">Nom Medecin</th>
            <!-- <th class="table-headin">Prenom </th>
            <th class="table-headin">Poste </th> -->
            <!-- <th class="table-headin">Specialite </th> -->
            <th class="table-headin">Action</th>
        </tr>
        </thead>
        <tbody>
        <?php
                //require_once "../../../projet_clinique_noMVC/config.php";
                //require_once "../../../projet_clinique_noMVC/connect.php";
                require_once "connect.php";
                $specialite=$_POST['specialite'];
                $query="SELECT * FROM specialite INNER JOIN personnel ON specialite.idSpecialite=personnel.idSpecialite WHERE libelleSpecialite LIKE '$specialite'";
                $resultat=$connection->query($query);
                $resultat->setFetchMode(PDO::FETCH_OBJ);
                $ligne=$resultat->fetch();
                if($ligne==false){ ?>
                <tr>
                    <td class="label-td" colspan="2">
                        <h2>il y a pas medecin!!!</h2>
                    </td>
                </tr>
                <?php
                }
                else{
                    do{
                    ?>
                    <tr>
                        <form class="rdv" method="post">
                        <td style="text-align:center;" name="nommedecin">&nbsp;<div>
                            <input type="text" class="input-text" style="text-align:center;"  name="nommedecin" value="<?php echo $ligne->nomPersonnel ?>" readonly/>
                            <input type="hidden" name="idmed" class="listmed" value="<?php echo $ligne->idPersonnel ?>"/>
                        </div>   
                    </td>
                        <td>
                            <div style="display:flex;justify-content: center;">
                            <input type="submit" class="btn-primary-soft btn button-icon btn-edit tn-in-text"  style="padding-left: 40px;padding-top: 12px;padding-bottom: 12px;margin-top: 10px;" name="prendrerdv" value="Prendre rdv" formaction="pageAdmin.php?modele=prendreRDV"/>
                            </div>
                        </td>
                        </form>  
                    </tr>
                        
                                                  
                    <?php
                    }while($ligne=$resultat->fetch());
                }
	        	$resultat->closeCursor();
                ?>
        </tbody>
        
        


<?php } ?>
