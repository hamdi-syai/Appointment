<?php   
session_start();

if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
    echo "<center>Untuk mengakses modul, Anda harus login <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else {?>

    <thead>
        <tr>
            <th class="table-headin">Numero securite Social</th>
            <th class="table-headin">Date de RDV</th>
            <th class="table-headin">Motif RDV</th>
            <th class="table-headin">Action</th>
        </tr>
    </thead>
    <tbody>
    <?php
        //require_once "../../../projet_clinique_noMVC/config.php";
        //require_once "../../../projet_clinique_noMVC/connect.php";
        require_once "connect.php";
            $rawdate = htmlentities($_POST['day1']);
            $day = date('Y-m-d H:i', strtotime($rawdate));
            //$heure = $_POST['hours'];
            $idmed = $_POST['idmed'];
            $numsecu = $_POST['numsecu'];
            $nommedecin = $_POST['nommedecin'];
            $query="select * from rdv inner join  personnel on rdv.idPersonnel=personnel.idPersonnel";
            $resultat=$connection->query($query);
            $resultat->setFetchMode(PDO::FETCH_OBJ);
            $ligne=$resultat->fetch(); ?>
            <tr>
                <form method="post">
                <td style="text-align:center;">&nbsp;
                    <div><input type="text" style="text-align:center;" class="input-text" name="numsecu" value="<?php echo $numsecu;?>" readonly/>
                    </div>
                </td>
                <td style="text-align:center;">&nbsp;
                    <div><input type="text" style="text-align:center;" class="input-text" name="day2" value="<?php echo $day;?>" readonly/><input type="hidden" name="idmed" value="<?php echo $idmed;?>" readonly/>
                    <input type="hidden" name="nommedecin" value="<?php echo $nommedecin;?>"/>
                    </div>
                </td>
                <td style="text-align:center;">&nbsp;
                    <select name="motif" id="" class="input-text">
                                <?php
                                require_once "connect.php";
                                $queryMotif= "SELECT * from motif";
                                $resultat=$connection->query($queryMotif);
                                $resultat->setFetchMode(PDO::FETCH_OBJ);
                                while($ligne = $resultat->fetch()){
                                ?>
                                    <option value="<?php echo $ligne->idMotif; ?>"><?php echo $ligne->libelleMotif; ?></option>
                                <?php } ?>
                    </select>
                    </td>  
                <td>
					<div style="display:flex;justify-content: center;">
                        <input type="submit" class="btn-primary-soft btn button-icon btn-edit tn-in-text"  style="padding-left: 40px;padding-top: 12px;padding-bottom: 12px;margin-top: 10px;" name="validerrdv1" value="Valider" formaction="pageAdmin.php?modele=validerRDV"/>
                    </div>
				</td>
                </form>
			<?php $resultat->closeCursor(); ?>
            </tr>
<?php } ?>
