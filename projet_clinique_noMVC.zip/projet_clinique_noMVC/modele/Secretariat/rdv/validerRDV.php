<?php   
session_start();

if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
    echo "<center>Pour acceder le module essaye de se connecter <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else { ?>
    <tbody>
        <?php
        $rawdate = htmlentities($_POST['day2']);
        $day = date('Y-m-d H:i', strtotime($rawdate));
        //$heure = $_POST['hours'];
        $idmed = $_POST['idmed'];
        $numsecu = $_POST['numsecu'];
        $motif = $_POST['motif'];
        $queryTache="SELECT * FROM tacheadmin INNER JOIN personnel ON tacheadmin.idPersonnel=personnel.idPersonnel WHERE personnel.idPersonnel ='$idmed' and dateTache = '$day'";
        $queryRdv="SELECT * from rdv WHERE idPersonnel ='$idmed' and dateRDV = '$day'";
        $stmt1 = $connection->query($queryTache);
        $results1 = $stmt1->fetchAll(PDO::FETCH_OBJ);
        $stmt2 = $connection->query($queryRdv);
        $results2 = $stmt2->fetchAll(PDO::FETCH_OBJ);
        //$etatrdv=$results2->etatRDV;
        $results = array_merge($results1, $results2);
        /* $resultat=$connection->query($queryTache);
        $resultat1=$connection->query($queryRdv);
        $resultat->setFetchMode(PDO::FETCH_OBJ);
        $resultat1->setFetchMode(PDO::FETCH_OBJ);
        //$results=array_merge($resultat);
        $ligne1=$resultat->fetch();
        $linge2=$resultat1->fetch();
        $ligne = array_merge($ligne1,$linge2); */

        if ($results == true) { ?>
            <h1>le medecin ou la date de RDV n'est pas disponible!</h1></br>
            <h2>essaye de change le medecin ou la date!</h2>
        <?php }else {
            
            //require_once "../../../projet_clinique_noMVC/config.php";
            //require_once "../../../projet_clinique_noMVC/connect.php";
               /*  require_once "connect.php";
                $rawdate = htmlentities($_POST['day2']);
                $day = date('Y-m-d H:i', strtotime($rawdate));
                //$heure = $_POST['hours'];
                $idmed = $_POST['idmed'];
                $numsecu = $_POST['numsecu']; */
                $query="insert into rdv (dateRDV, nss, idPersonnel, idMotif) values('$day', $numsecu, $idmed, $motif)";
                $resultat = $connection->query($query);      
                //echo'bravo';
                $queryEtat="SELECT * from rdv inner join motif on rdv.idMotif = motif.idMotif inner join piecesmotif on motif.idMotif = piecesmotif.idMotif inner join pieces on piecesmotif.idPieces = pieces.idPieces WHERE idPersonnel ='$idmed' and dateRDV = '$day'";
                $etat=$connection->query($queryEtat);
		        $etat->setFetchMode(PDO::FETCH_OBJ);  
                $etatrdv=$etat->fetch();   
                $querypieces="SELECT * from pieces inner join piecesmotif on pieces.idPieces=piecesmotif.idPieces inner join motif on piecesmotif.idMotif=motif.idMotif where motif.idMotif='$motif'"; 
                $pieces=$connection->query($querypieces);
		        $pieces->setFetchMode(PDO::FETCH_OBJ);  
                      
                echo'<h1>Vous avez un rendez-vous le '.$day.'</h1></br><h2>'.$etatrdv->etatRDV.'</h2><select class="input-text">';
                while($ligne=$pieces->fetch()){
                    echo'<option>'.$ligne->libellePieces.'</option>';
                }
                echo'</select></form>';
                $resultat->closeCursor();
    
                
     }
        }
        ?>

    </tbody>
    
