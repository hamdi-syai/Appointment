<?php   
session_start();

if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
    echo "<center>Untuk mengakses modul, Anda harus login <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else { ?>   


        <thead>
        <?php
                //require_once "../../../projet_clinique_noMVC/config.php";
                //require_once "../../../projet_clinique_noMVC/connect.php";
                require_once "connect.php";
                $nommedecin=$_POST['nommedecin'];
                $idmed=$_POST['idmed'];
                $query="SELECT * FROM rdv INNER JOIN personnel ON rdv.idPersonnel=personnel.idPersonnel WHERE nomPersonnel LIKE '%$nommedecin%'";
                $resultat=$connection->query($query);
                $resultat->setFetchMode(PDO::FETCH_OBJ);
                $ligne=$resultat->fetch();
                ?>
        <tr>
            <th class="table-headin" colspan="2">Prendre RDV avec docteur <?php echo $nommedecin ?></th>
                
            <!-- <th class="table-headin">Prendre RDV</th>
            <th class="table-headin">Prenom </th>
            <th class="table-headin">Poste </th> 
            <th class="table-headin">Specialite </th> 
            <th class="table-headin">Action</th> -->
        </tr>
        </thead>
        <tbody>
        <?php
                //require_once "../../../projet_clinique_noMVC/config.php";
                //require_once "../../../projet_clinique_noMVC/connect.php";
                require_once "connect.php";
                $nommedecin=$_POST['nommedecin'];
                $idmed=$_POST['idmed'];
                $query="SELECT * FROM rdv INNER JOIN personnel ON rdv.idPersonnel=personnel.idPersonnel WHERE nomPersonnel LIKE '%$nommedecin%'";
                $resultat=$connection->query($query);
                $resultat->setFetchMode(PDO::FETCH_OBJ);
                $ligne=$resultat->fetch();
                ?>
                <tr>
                    <td colspan="2" style="padding-top:25px;">   
                            Choisir la date de RDV          
                    </td>
                </tr>
                <tr>
                <form method="post">
                    <td>
                        <div>
                            <input type="hidden" name="idmed" value="<?php echo $idmed ?>"/>
                            <input type="hidden" name="nommedecin" value="<?php echo $nommedecin ?>"/>
                            <!-- <input type="datetime-local" class="input-text" name="daterdv" step="3600" required> -->
                            <?php
                     $time=new DateTime('07:00');
                     $interval=new DateInterval('PT1H');
                     $beginDay=new DateTime('tomorrow 08:00');
                     $endDay=new DateTime('last day of next month 19:00');
                     $endDay=$endDay->modify('+1 day');
                     $interval1=new DateInterval('P1D');
                     $endTime = new DateTime('19:00');
                     //$saturday = new DateTime('Saturday');
                     //$monday = new DateTime('monday');
                     $weekend = array('Saturday', 'Sunday');
                     $closeHours = array('19:00', $interval,'08:00');
                     //$daterange=new DatePeriod($beginDay,$interval1,$endDay);
                     //$idmed = $_POST['idmed'];
                    $queryTache="SELECT * FROM tacheadmin INNER JOIN personnel ON tacheadmin.idPersonnel=personnel.idPersonnel WHERE personnel.idPersonnel ='$idmed'";
                    $queryRDV="SELECT * FROM rdv INNER JOIN personnel ON rdv.idPersonnel=personnel.idPersonnel WHERE personnel.idPersonnel ='$idmed'";
                    $resultTache=$connection->query($queryTache);
                    $resultTache->setFetchMode(PDO::FETCH_OBJ);
                    $resultRDV=$connection->query($queryRDV);
                    $resultRDV->setFetchMode(PDO::FETCH_OBJ);
                    while($ligneRDV=$resultRDV->fetch()){
                        $rdvArray[] = $ligneRDV; // store all results
                    }
                    while($ligneTache=$resultTache->fetch()){
                        $tacheArray[] = $ligneTache; // store all results
                    }
                    
                     echo'<select name="daterdv" class="box">';
                         for ($i=$beginDay; $i < $endDay ; $i->add($interval)) { 
                           /* $queryTache="SELECT * FROM tacheadmin INNER JOIN personnel ON tacheadmin.idPersonnel=personnel.idPersonnel WHERE personnel.idPersonnel ='$idmed'";
                            $queryRDV="SELECT * FROM rdv INNER JOIN personnel ON rdv.idPersonnel=personnel.idPersonnel WHERE personnel.idPersonnel ='$idmed'";
                            $resultTache=$connection->query($queryTache);
                            $resultTache->setFetchMode(PDO::FETCH_OBJ);
                            $resultRDV=$connection->query($queryRDV);
                            $resultRDV->setFetchMode(PDO::FETCH_OBJ);
                             while($ligneRDV=$resultRDV->fetch()){
                                $rdvArray[] = $ligneRDV; // store all results
                            }
                            while($ligneTache=$resultTache->fetch()){
                                $tacheArray[] = $ligneTache; // store all results
                            } */
                            
                            if (in_array($i->format('l'), $weekend) || $i->format('H:i') >= $closeHours[0] || $i->format('H:i') < $closeHours[2]) {
                                echo'<option value="'.$i->format('Y-m-d H').'" >Closed</option>';
                            } elseif(($rdv = in_array($i->format('Y-m-d H:i:s'), array_column($rdvArray, 'dateRDV'))) || ($tache = in_array($i->format('Y-m-d H:i:s'), array_column($tacheArray, 'dateTache')))){
                                echo'<option >Indisponible</option>';
                            }
                       
                            else{
                            echo'<option >'.$i->format('l Y-m-d H:i').'</option>';
                        
                        }
                        }
                         echo'</select>';
                         ?>
                        </div>
                    </td>                        
                    <td>
                        <div style="display:flex;justify-content: center;">
                            <input type="submit" class="btn-primary-soft btn button-icon btn-edit tn-in-text"  style="padding-left: 40px;padding-top: 12px;padding-bottom: 12px;margin-top: 10px;" name="rdvmedecin" value="Prendre rdv" formaction="pageAdmin.php?modele=rdvMedecin"/>
                        </div>
                    </td>
                    </form>
                    <?php $resultat->closeCursor(); 
                ?>
                </tr>
              
        </tbody>
        
<?php } ?>
