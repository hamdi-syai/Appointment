<?php
     require_once "../../../../projet_clinique_NOMVC/connect.php";
    require_once "../../../../projet_clinique_noMVC/config.php";
    // Check if the form was submitted with a POST request
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nss = $_POST['numsecu'];
    $nom = $_POST['nomPatient'];
    $prenom = $_POST['prenomPatient'];
    $adresse = $_POST['adressePatient'];
    $deptnais = $_POST['deptNaiss'];
    //$deptNaissance = isset($_POST['deptNaissance']) ? $_POST['deptNaissance'] : '';
    //$deptNaissance = $_POST['deptNaissance'];
    $numtel = $_POST['numtel'];
    $datenais = $_POST['datenais'];
    $solde = $_POST['soldePatient'];
    //$deptNaissance = null;
    
        // Check if the hidden input field "deptFlag" is set to "1"
        /* if (isset($_POST['deptFlag']) && $_POST['deptFlag'] === '1') {
        // Get the value of the department of birth from the form data
        $deptNaissance = $_POST['deptNaissance'];
    /* if (/* $resultat == true &&  !empty($nss) && !empty($nom) && !empty($prenom) && !empty($adresse) && !empty($numtel) && !empty($datenais) /* && !empty($deptnais) ) {
        if (!empty($deptNaissance)) { 
            //$dept = !empty($deptNaissance) ? $deptNaissance : $deptnais;
            //array_push($dept_array, $dept);
            $stmt = ("Insert into patient(nss, nomPatient, prenomPatient, adresse, numTel, dateNais, departementNais, solde) values ('$nss', '$nom', '$prenom', '$adresse', '$numtel', '$datenais',  '$deptNaissance', '$solde' )");
            $resultat = $connection->query($stmt);
            $resultat->closeCursor();
            /* $stmt->bindParam(':dept', implode(", ", $dept_array));
            $stmt->execute(); 
        } else {
            $queryEnregistre = "Insert into patient(nss, nomPatient, prenomPatient, adresse, numTel, dateNais, departementNais, solde) values ('$nss', '$nom', '$prenom', '$adresse', '$numtel', '$datenais', '$deptnais', '$solde' )";
            $resultat = $connection->query($queryEnregistre);
            $resultat->closeCursor();
        }
        //echo "<script> alert('Personnel a ete enregistre'); window.location='$url'+'pageAdmin.php?modele=patient';</script>"; 
        echo "<p>tampilkan'.$deptNaissance.'##</p>";
    } else {
        echo "<p>tampilkan'.$deptNaissance.'**</p>";
        //echo "<script> alert('les donnees n'est pas valide'); window.location ='$url'+'pageAdmin.php?modele=ajouterPatient'; </script>";
    }
 }}  */
 if (isset($_POST['deptFlag']) && $_POST['deptFlag'] === '1') {
    // Get the value of the department of birth from the form data
    $deptNaissance = isset($_POST['deptNaissance']) ? $_POST['deptNaissance'] : null;
    $stmt = $connection->prepare("INSERT INTO patient(nss, nomPatient, prenomPatient, adresse, numTel, dateNais, departementNais, solde) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$nss, $nom, $prenom, $adresse, $numtel, $datenais, $deptNaissance, $solde]);
    } else {
        $stmt = $connection->prepare("INSERT INTO patient(nss, nomPatient, prenomPatient, adresse, numTel, dateNais, departementNais, solde) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$nss, $nom, $prenom, $adresse, $numtel, $datenais, $deptnais, $solde]);
    }
    echo "<p>tampilkan " . $deptNaissance . "##</p>";
 // Use prepared statements with placeholders
 /* if (!empty($nss) && !empty($nom) && !empty($prenom) && !empty($adresse) && !empty($numtel) && !empty($datenais) && !empty($deptnais) && !empty($solde)) {
    if (!empty($deptNaissance)) {
        $stmt = $connection->prepare("INSERT INTO patient(nss, nomPatient, prenomPatient, adresse, numTel, dateNais, departementNais, solde) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$nss, $nom, $prenom, $adresse, $numtel, $datenais, $deptNaissance, $solde]);
    } else {
        $stmt = $connection->prepare("INSERT INTO patient(nss, nomPatient, prenomPatient, adresse, numTel, dateNais, departementNais, solde) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$nss, $nom, $prenom, $adresse, $numtel, $datenais, $deptnais, $solde]);
    }
    echo "<p>tampilkan " . $deptNaissance . "##</p>"; */
} else {
    echo "<p>tampilkan " . $deptnais . "**</p>";
}
    /* }
} */
?>