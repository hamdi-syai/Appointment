<?php   

if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])) {
    echo "<center>Untuk mengakses modul, Anda harus login <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else { ?>

<style>
        .popup{
            animation: transitionIn-Y-bottom 0.5s;
        }
        .sub-table{
            animation: transitionIn-Y-bottom 0.5s;
        }
</style>

    <div>
        <div>
            <center>
            <table width="80%" border="0">
                <tr>
                <form action="modele/Secretariat/patient/validerDepot.php" method="post">
                <?php
                            require_once "connect.php";
                            require_once "config.php";
                            $nss = $_GET['nss'];
                            $queryModif="SELECT * FROM patient where nss='$nss'";
                            $resultat=$connection->query($queryModif);
                            $resultat->setFetchMode(PDO::FETCH_OBJ);
                            while($ligne = $resultat->fetch()){
                            $nss = $ligne->nss;
                            $nom = $ligne->nomPatient;
                            $prenom = $ligne->prenomPatient;
                            $adresse = $ligne->adresse;
                            $numtel = $ligne->numTel;
                            $datenais = $ligne->dateNais;
                            $deptnais = $ligne->departementNais;
                            $solde = $ligne->solde;
                            }
                            ?>
                    <td class="label-td" colspan="2">
                    <input type="hidden" name="numsecu" value="<?php echo $nss; ?>">
                        <label for="name" class="form-label">Montant Depot : </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                    <input type="text" name="depotPatient" class="input-text"><br>
                                </td>
                                
                </tr>
                <tr>
                    <td colspan="2">
                        <input type="submit" value="Valider le depot" class="login-btn btn-primary btn">
                    </td>
                </tr>
                </form>
                </table>
            </center>
        </div>
    </div>

<?php } ?>