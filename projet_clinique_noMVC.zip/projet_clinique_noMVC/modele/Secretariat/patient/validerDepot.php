<?php
session_start();

if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
    echo "<center>Untuk mengakses modul, Anda harus login <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else {

    require_once "../../../../projet_clinique_noMVC/config.php";
    require_once "../../../../projet_clinique_noMVC/connect.php";
    $nss = $_POST['numsecu'];
    $depot = $_POST['depotPatient'];
    $query="SELECT * FROM patient where nss='$nss'";
    $resultat=$connection->query($query);
    $resultat->setFetchMode(PDO::FETCH_OBJ);
    $ligne = $resultat->fetch();
    $solde = $ligne->solde;
    $totalDepot = $solde + $depot;
    $queryDepot = "UPDATE patient SET solde='$totalDepot' WHERE nss='$nss'";
    $resultat = $connection->query($queryDepot);
    $resultat->closeCursor();
    //echo $totalDepot;
    
    if ($resultat == true) {
        //echo $totalDepot;
        echo "<script> alert('votre solde est mis a jour $totalDepot'); window.location='$url'+'pageAdmin.php?modele=patient'; </script>";
    } else {
        echo "<script> alert('les donnees nest pas valide'); window.location ='$url'+'pageAdmin.php?modele=modifierPatient&nss='+''$nss'; </script>";
    }
}
?>