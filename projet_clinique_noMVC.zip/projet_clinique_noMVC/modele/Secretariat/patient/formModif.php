<?php   

if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])) {
    echo "<center>Untuk mengakses modul, Anda harus login <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else { ?>

<style>
        .popup{
            animation: transitionIn-Y-bottom 0.5s;
        }
        .sub-table{
            animation: transitionIn-Y-bottom 0.5s;
        }
</style>

    <div>
        <div>
            <center>
            <table width="80%" border="0">
            <tr>
                <td class="label-td" colspan="2"></td>
            </tr>
                <tr>
                    <td>
                        <p style="padding: 0;margin: 0;text-align: left;font-size: 25px;font-weight: 500;">Modifier Personnel.</p><br><br>
                    </td>
                </tr>
                <tr>
                <form action="modele/Secretariat/patient/modifier.php" method="post">
                            <?php
                            require_once "connect.php";
                            require_once "config.php";
                            $nss = $_GET['nss'];
                            $queryModif="SELECT * FROM patient where nss='$nss'";
                            $resultat=$connection->query($queryModif);
                            $resultat->setFetchMode(PDO::FETCH_OBJ);
                            while($ligne = $resultat->fetch()){
                            $nss = $ligne->nss;
                            $nom = $ligne->nomPatient;
                            $prenom = $ligne->prenomPatient;
                            $adresse = $ligne->adresse;
                            $numtel = $ligne->numTel;
                            $datenais = $ligne->dateNais;
                            $deptnais = $ligne->departementNais;
                            $solde = $ligne->solde;
                            }
                            ?>
                        
                        <td class="label-td" colspan="2">
                        <input type="hidden" name="numsecu" value="<?php echo $nss; ?>">
                        <label for="name" class="form-label">Nom Patient : </label>
                    </td>

                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                    <input type="text" name="nomPatient" value="<?php echo $nom; ?>" class="input-text" required><br>
                                </td>
                                
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <label for="name" class="form-label">Prenom Patient : </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                    <input type="text" name="prenomPatient" value="<?php echo $prenom; ?>" class="input-text" required><br>
                                </td>
                                
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <label for="name" class="form-label">Adresse : </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                    <input type="text" name="adressePatient" value="<?php echo $adresse; ?>" class="input-text" required><br>
                                </td>
                                
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <label for="name" class="form-label">Departement Naissance : </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                    <input type="text" name="deptNaiss" value="<?php echo $deptnais; ?>" class="input-text" required><br>
                                </td>
                                
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <label for="name" class="form-label">Numero telephone : </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                    <input type="tel" name="numtel" pattern="[0-9]{10}" placeholder="Please enter exactly 10 digits" minlength="10" maxlength="10" value="<?php echo $numtel; ?>" class="input-text" required><br>
                                </td>
                                
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <label for="name" class="form-label">Date de naissance : </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                    <input type="date" name="datenais" value="<?php echo $datenais; ?>" class="input-text" required><br>
                                </td>
                                
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <label for="name" class="form-label">Solde : </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                    <input type="number" name="soldePatient" value="<?php echo $solde; ?>" class="input-text" required><br>
                                </td>
                                
                </tr>
                <tr>
                    <td colspan="2">
                        <input type="submit" value="Modifier" class="login-btn btn-primary btn">
                    </td>
                </tr>
                </form>
                </table>
            </center>
        </div>
    </div>

<?php } ?>