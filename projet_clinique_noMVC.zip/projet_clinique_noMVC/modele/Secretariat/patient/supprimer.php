<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
    echo "<center>Untuk mengakses modul, Anda harus login <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else {

    require_once "../../../../projet_clinique_noMVC/config.php";
    require_once "../../../../projet_clinique_noMVC/connect.php";

    $nss = $_GET['nss'];
    $querySupprimer = "DELETE FROM patient WHERE nss='$nss'";
    $resultat=$connection->query($querySupprimer);
	$resultat->closeCursor();
    if ($resultat == true) {
        echo "<script> alert('Data Member Berhasil Dihapus'); window.location = '$url'+'pageAdmin.php?modele=patient';</script>";
    } else {
        echo "<script> alert('Data Member Gagal Dihapus'); window.location = '$url'+'pageAdmin.php?modele=patient';</script>";

    }
}
?>