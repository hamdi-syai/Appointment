<?php   

if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
    echo "<center>Untuk mengakses modul, Anda harus login <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else { ?>


    <thead>
        <tr>
            <th class="table-headin">Numero Securite Social</th>
            <th class="table-headin">Nom Patient</th>
            <th class="table-headin">Prenom Patient</th>
            <th class="table-headin">Address</th>
            <th class="table-headin">Numero Telephone</th>
            <th class="table-headin">Date de Naissance</th>
            <th class="table-headin">Departement de Naissance</th>
            <th class="table-headin">Solde</th>
            <th class="table-headin">Action</th>
        </tr>
</thead>
<tbody>
<tr>

        <?php
        if(isset($_POST["search"])){
            //$keyword=$_POST["search"];
            require_once "connect.php";
            $mainquery= "select * from patient where nomPatient='$keyword' or prenomPatient='$keyword' or nomPatient like '$keyword%' or prenomPatient like '%$keyword' or prenomPatient like '%$keyword%' ";
            $resultat=$connection->query($mainquery);
		    $resultat->setFetchMode(PDO::FETCH_OBJ);
            $ligne=$resultat->fetch();
            if ($ligne == false) {?>
                <tr>
                                        <td colspan="4">
                                        <br><br><br><br>
                                        <center>
                                        <img src="img/notfound.svg" width="25%">
                                        
                                        <br>
                                        <p class="heading-main12" style="margin-left: 45px;font-size:20px;color:rgb(49, 49, 49)">We  couldnt find anything related to your keywords !</p>
                                        <a class="non-style-link" href="pageAdmin.php?modele=patient"><button  class="login-btn btn-primary-soft btn"  style="display: flex;justify-content: center;align-items: center;margin-left:20px;">&nbsp; Show all Patients &nbsp;</font></button>
                                        </a>
                                        </center>
                                        <br><br><br><br>
                                        </td>
                                        </tr>';
            <?php 
            }else{
                for ($k=0; $k < $ligne; $k++) { ?>
                    <tr>
                <td>&nbsp;<?php echo $ligne->nss;?></td>
                <td>&nbsp;<?php echo $ligne->nomPatient;?></td>
                <td>&nbsp;<?php echo $ligne->prenomPatient;?></td>
                <td>&nbsp;<?php echo $ligne->adresse;?></td>
                <td>&nbsp;<?php echo $ligne->numTel;?></td>
                <td>&nbsp;<?php echo $ligne->dateNais;?></td>
                <td>&nbsp;<?php echo $ligne->departementNais;?></td>
                <td>&nbsp;<?php echo $ligne->solde;?></td>
                <td>
                    <div style="display:flex;justify-content: center;">
                    <a href="pageAdmin.php?modele=modifierPatient&nss=<?php echo $ligne->nss;?>" class="non-style-link"><button  class="btn-primary-soft btn button-icon btn-edit"  style="padding-left: 40px;padding-top: 12px;padding-bottom: 12px;margin-top: 10px;"><font class="tn-in-text">Modifier</font></button></a>
                   &nbsp;&nbsp;&nbsp;
                   <a href="modele/Secretariat/patient/supprimer.php?nss=<?php echo $ligne->nss;?>" class="non-style-link"><button  class="btn-primary-soft btn button-icon btn-delete"  style="padding-left: 40px;padding-top: 12px;padding-bottom: 12px;margin-top: 10px;" onClick="return confirm('vous-etez sure de supprimer ?')"><font class="tn-in-text">Supprimer</font></button></a>
                    </div>
                </td>
            </tr>
            <?php
                } }
            

        }else{
            require_once "connect.php";
            $mainquery= "select * from patient";
            $resultat=$connection->query($mainquery);
		    $resultat->setFetchMode(PDO::FETCH_OBJ);
            while($ligne=$resultat->fetch()){
                ?>
                <tr>
                <td>&nbsp;<?php echo $ligne->nss;?></td>
                <td>&nbsp;<?php echo $ligne->nomPatient;?></td>
                <td>&nbsp;<?php echo $ligne->prenomPatient;?></td>
                <td>&nbsp;<?php echo $ligne->adresse;?></td>
                <td>&nbsp;<?php echo $ligne->numTel;?></td>
                <td>&nbsp;<?php echo $ligne->dateNais;?></td>
                <td>&nbsp;<?php echo $ligne->departementNais;?></td>
                <td>&nbsp;<?php echo $ligne->solde;?></td>
                <td>
                    <div style="display:flex;justify-content: center;">
                    <a href="pageAdmin.php?modele=modifierPatient&nss=<?php echo $ligne->nss;?>" class="non-style-link"><button  class="btn-primary-soft btn button-icon btn-edit"  style="padding-left: 40px;padding-top: 12px;padding-bottom: 12px;margin-top: 10px;"><font class="tn-in-text">Modifier</font></button></a>
                   &nbsp;&nbsp;&nbsp;
                   <a href="pageAdmin.php?modele=depotPatient&nss=<?php echo $ligne->nss;?>" class="non-style-link"><button  class="btn-primary-soft btn button-icon btn-depot"  style="padding-left: 40px;padding-top: 12px;padding-bottom: 12px;margin-top: 10px;"><font class="tn-in-text">Depot</font></button></a>
                   &nbsp;&nbsp;&nbsp;
                   <a href="modele/Secretariat/patient/supprimer.php?nss=<?php echo $ligne->nss;?>" class="non-style-link"><button  class="btn-primary-soft btn button-icon btn-delete"  style="padding-left: 40px;padding-top: 12px;padding-bottom: 12px;margin-top: 10px;" onClick="return confirm('vous-etez sure de supprimer ?')"><font class="tn-in-text">Supprimer</font></button></a>
                    </div>
                </td>
            </tr>
            <?php } ?>

        
        
        <tr >
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td>&nbsp;&nbsp;&nbsp;</td>
                    <td style="padding-top:30px;">
                    <div style="display:flex;justify-content: center;">
                    <a href="pageAdmin.php?modele=ajouterPatient" class="non-style-link"><button  class="login-btn btn-primary btn button-icon"  style="margin-top: 10px; display: flex;justify-content: center;align-items: center;margin-left:123px;background-image: url('img/icons/add.svg');">Creer Patient</font></button></a>
                    </div>
                    </td>
    </tr>
    </table>

        </tbody>





<?php } } ?>