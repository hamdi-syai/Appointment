<?php   
 //session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
    echo "<center>Untuk mengakses modul, Anda harus login <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else { ?>
<style>
        .popup{
            animation: transitionIn-Y-bottom 0.5s;
        }
        .sub-table{
            animation: transitionIn-Y-bottom 0.5s;
        }
</style>
<div>
     <div>
        <center>
            <table width="80%" border="0">
            <tr>
                <td class="label-td" colspan="2"></td>
            </tr>
                <tr>
                    <td>
                        <p style="padding: 0;margin: 0;text-align: left;font-size: 25px;font-weight: 500;">Ajouter Personnel</p><br><br>
                    </td>
                </tr>
                <tr>
                <form action="modele/Secretariat/patient/enregistre.php" method="post" class="add-new-form" id="p1">
                    <td class="label-td" colspan="2">
                        <label for="name" class="form-label">Numero Securite Social : </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <input type="text" name="numsecu" placeholder="15 caractères" size="15" minlength="15" maxlength="15" class="input-text" required><br>
                                </td>
                                
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <label for="name" class="form-label">Nom Patient : </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                    <input type="text" name="nomPatient" class="input-text" placeholder="Prenom Personnel" required><br>
                                </td>
                                
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <label for="name" class="form-label">Prenom Patient : </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                    <input type="text" name="prenomPatient" class="input-text" placeholder="Prenom Personnel" required><br>
                                </td>
                                
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <label for="name" class="form-label">Adresse : </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                    <input type="text" name="adressePatient" class="input-text" placeholder="Prenom Personnel" required><br>
                                </td>
                                
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <label for="name" class="form-label">Departement Naissance : </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                    <input type="text" id="myDept" name="deptNaiss" class="input-text" placeholder="Departement de Naissance" required><br>
                    <script>
                            var input = document.getElementById("myDept");
                            //let y = 99;
                            input.addEventListener("blur", function() {
                                if (input.value == "99") {
                                    //alert("Input value is 99");
                                //}
                                let table = document.getElementById("p2");
                                let row = document.createElement("tr");
                                let cell = document.createElement("td");
                                let input = document.createElement("input");
                                input.setAttribute("type", "text");
                                input.setAttribute("class", "input-text");
                                input.setAttribute("name", "deptNaissance");
                                input.setAttribute("id", "deptNaissanceInput");
                                cell.appendChild(input);
                                row.appendChild(cell);
                                table.appendChild(row);
                                document.getElementsByName("deptFlag")[0].value = "1"; 
                                // Send an AJAX request to save the input value to the database
                                /* var xhttp = new XMLHttpRequest();
                                xhttp.onreadystatechange = function() {
                                    if (this.readyState == 4 && this.status == 200) {
                                    console.log("Data saved to database");
                                    }
                                };
                                xhttp.open("POST", "enregistre.php", true);
                                xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                                xhttp.send("deptNaissance=" + input.value); */
                                

                            }
                            });
                            // Submit the form when the user clicks the Save button
                            document.querySelector('input[type="submit"]').addEventListener("click", function(e) {
                            // Check if the new input field is present and has a value
                            if (document.getElementById("deptNaissance") && document.getElementById("deptNaissance").value) {
                            // Set the value of the hidden input field to "1"
                            document.getElementsByName("deptFlag")[0].value = "1";
                            }
                            // Prevent the default form submission
                            e.preventDefault();
                            // Submit the form using JavaScript
                            document.querySelector("form").submit();
                            });
                        
                    </script>
                    <div id="p2"></div>
                    <input type="hidden" name="deptFlag" value="0">
                    
                    </td>
                                
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <label for="name" class="form-label">Numero telephone : </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                    <input type="tel" name="numtel" pattern="[0-9]{10}" placeholder="Please enter exactly 10 digits" minlength="10" maxlength="10" class="input-text" required><br>
                                </td>
                                
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <label for="name" class="form-label">Date de naissance : </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                    <input type="date" name="datenais" class="input-text" placeholder="Prenom Personnel" required><br>
                                </td>
                                
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <label for="name" class="form-label">Solde : </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                    <input type="number" name="soldePatient" class="input-text" placeholder="Prenom Personnel" required><br>
                                </td>
                                
                </tr>
                <tr>
                    <td colspan="2">
                        <input type="reset" value="Reset" class="login-btn btn-primary-soft btn" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    
                        <input type="submit" value="Enregistre" class="login-btn btn-primary btn">
                    </td>
                </tr>
                </form>
    </tr>
    </table>
    </center>
    <br></br>
    </div>
    </div>
<?php } ?>