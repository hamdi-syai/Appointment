<?php
session_start();

if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
    echo "<center>Untuk mengakses modul, Anda harus login <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else {

    require_once "../../../../projet_clinique_noMVC/config.php";
    require_once "../../../../projet_clinique_noMVC/connect.php";
    $nss = $_POST['numsecu'];
    $nom = $_POST['nomPatient'];
    $prenom = $_POST['prenomPatient'];
    $adresse = $_POST['adressePatient'];
    $deptnais = $_POST['deptNaiss'];
    $numtel = $_POST['numtel'];
    $datenais = $_POST['datenais'];
    $solde = $_POST['soldePatient'];
    $queryModif = "UPDATE patient SET nomPatient='$nom', prenomPatient='$prenom', adresse='$adresse', numTel='$numtel', dateNais='$datenais', departementNais='$deptnais', solde='$solde' WHERE nss='$nss'";
    $resultat = $connection->query($queryModif);
    $resultat->closeCursor();
    if ($resultat == true && !empty($nss) && !empty($nom) && !empty($prenom) && !empty($adresse) && !empty($numtel) && !empty($datenais) && !empty($deptnais)) {
        echo "<script> alert('Personnel a ete enregistre'); window.location='$url'+'pageAdmin.php?modele=patient';</script>";
    } else {
        echo "<script> alert('les donnees nest pas valide'); window.location ='$url'+'pageAdmin.php?modele=modifierPatient&nss='+''$nss'; </script>";
    }
}
?>