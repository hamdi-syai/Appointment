<?php   

if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
    echo "<center>Untuk mengakses modul, Anda harus login <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else { ?>       
        
        <center>
		<table width="80%" border="0">
            <tr>
                <td class="label-td" colspan="2"></td>
            </tr>
                <tr>
                    <td>
                        <p style="padding: 0;margin: 0;text-align: left;font-size: 25px;font-weight: 500;">Consulter fiche patient</p><br><br>
                    </td>
                </tr>
				<tr>
				<form method="post">
					<td class="label-td" colspan="2">
                        <label for="name" class="form-label">Numero Securite Sociale : </label>
                    </td>
				</tr>
				<tr>
                    <td class="label-td" colspan="2">
                    <input type="text" name="nss" class="input-text" maxlength="15" size="15" minlength="15" placeholder="Numero Securite Sociale" required><br>
                                </td>
                                
                </tr>
				<tr>
                    <td colspan="2">                    
                        <input type="submit" formaction="pageAdmin.php?modele=affichePatient" value="Recherche Patient" class="login-btn btn-primary btn">
                    </td>
                </tr>

				</form>
                </table>
				
</center>

<?php } ?>
