<?php   

if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
    echo "<center>Untuk mengakses modul, Anda harus login <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else { ?>


    <thead>
        <tr>
            <th class="table-headin">Numero Securite Social</th>
            <th class="table-headin">Nom Patient</th>
            <th class="table-headin">Prenom Patient</th>
            <th class="table-headin">Solde</th>
            <th class="table-headin">Date RDV</th>
            <th class="table-headin">Medecin</th>
            <th class="table-headin">Motif</th>
            <th class="table-headin">Prix RDV</th>
            <th class="table-headin">Etat RDV</th>
            <th class="table-headin">Action</th>
        </tr>
</thead>
<tbody>
<tr>

        <?php
            require_once "connect.php";
            $nss = $_POST['nss'];
            $mainquery="SELECT * from patient inner join rdv on patient.nss= rdv.nss join personnel on rdv.idPersonnel = personnel.idPersonnel join motif on rdv.idMotif = motif.idMotif where patient.nss='$nss' /* and etatRDV='En attend de paiement' */";
            $resultat=$connection->query($mainquery);
		    $resultat->setFetchMode(PDO::FETCH_OBJ);
            while($ligne=$resultat->fetch()){
                ?>
                <tr>
                <td style="text-align:center;">&nbsp;<?php echo $ligne->nss;?></td>
                <td style="text-align:center;">&nbsp;<?php echo $ligne->nomPatient;?></td>
                <td style="text-align:center;">&nbsp;<?php echo $ligne->prenomPatient;?></td>
                <td style="text-align:center;">&nbsp;<?php echo $ligne->solde;?></td>
                <td style="text-align:center;">&nbsp;<?php echo $ligne->dateRDV;?></td>
                <td>&nbsp;<?php echo $ligne->nomPersonnel;?></td>
                <td style="text-align:center;">&nbsp;<?php echo $ligne->libelleMotif;?></td>
                <td style="text-align:center;">&nbsp;<?php echo $ligne->prixMotif;?></td>
                <td style="text-align:center;">&nbsp;<?php echo $ligne->etatRDV;?></td>
                <td>
                    <div style="display:flex;justify-content: center;">
                    <a href="pageAdmin.php?modele=paiementPatient&nss=<?php echo $ligne->nss;?>&idRDV=<?php echo $ligne->idRDV;?>" class="non-style-link"><button  class="btn-primary-soft btn button-icon btn-depot"  style="padding-left: 40px;padding-top: 12px;padding-bottom: 12px;margin-top: 10px;"><font class="tn-in-text">Payer</font></button></a>
                   &nbsp;&nbsp;&nbsp;
                   <a href="modele/Secretariat/patient/supprimer.php?nss=<?php echo $ligne->nss;?>" class="non-style-link"><button  class="btn-primary-soft btn button-icon btn-delete"  style="padding-left: 40px;padding-top: 12px;padding-bottom: 12px;margin-top: 10px;" onClick="return confirm('vous-etez sure de supprimer ?')"><font class="tn-in-text">Supprimer</font></button></a>
                    </div>
                </td>
            </tr>
            <?php } ?>

        
        
        <!-- <tr >
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td>&nbsp;&nbsp;&nbsp;</td>
            <td>&nbsp;&nbsp;&nbsp;</td>
                    <td style="padding-top:30px;">
                    <div style="display:flex;justify-content: center;">
                    <a href="pageAdmin.php?modele=ajouterPatient" class="non-style-link"><button  class="login-btn btn-primary btn button-icon"  style="margin-top: 10px; display: flex;justify-content: center;align-items: center;margin-left:123px;background-image: url('img/icons/add.svg');">Creer Patient</font></button></a>
                    </div>
                    </td>
    </tr> -->
    </table>

        </tbody>





<?php } ?>