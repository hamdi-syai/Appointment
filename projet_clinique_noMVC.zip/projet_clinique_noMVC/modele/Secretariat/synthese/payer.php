<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
    echo "<center>Untuk mengakses modul, Anda harus login <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else {

    require_once "../projet_clinique_noMVC/config.php";
    require_once "../projet_clinique_noMVC/connect.php";

    $nss = $_GET['nss'];
    $idrdv = $_GET['idRDV'];
    $query = "SELECT * from patient inner join rdv on patient.nss= rdv.nss join personnel on rdv.idPersonnel = personnel.idPersonnel join motif on rdv.idMotif = motif.idMotif where patient.nss='$nss' and rdv.idRDV='$idrdv'";
    $resultat=$connection->query($query);
    $resultat->setFetchMode(PDO::FETCH_OBJ);
    $ligne = $resultat->fetch();
    $solde = $ligne->solde;
    $prix =$ligne->prixMotif;
    if ($solde>=$prix) {
        $payer = $solde - $prix;
        $querySolde = "UPDATE patient SET solde='$payer' WHERE nss='$nss'";
        $resultat = $connection->query($querySolde);
        $resultat->closeCursor();
        $queryPayer = "UPDATE rdv SET etatRDV='paiement validé' WHERE idRDV='$idrdv'";
        $result = $connection->query($queryPayer);
        $result->closeCursor();
        echo "<script> alert('Votre payement est valide'); window.location = '$url'+'pageAdmin.php?modele=patient';</script>";
    } else {
        echo"<h1>Votre solde n'est pas suffisant</h1>";
        //echo "<script> alert('Votre solde n'est pas suffisant'); window.location = '$url'+'pageAdmin.php?modele=patient';</script>";
    }

}
?>