<?php
    require_once "../../../../projet_clinique_NOMVC/connect.php";
    require_once "../../../../projet_clinique_noMVC/config.php";

    $pieces = $_POST['libellePieces'];
    $queryEnregistre = "Insert into pieces(libellePieces) values ('$pieces')";
    $resultat = $connection->query($queryEnregistre);
    $resultat->closeCursor();
    if ($resultat == true && !empty($pieces)) {
        echo "<script> alert('Pieces a ete enregistre'); window.location='$url'+'pageDirecteur.php?modele=listepieces';</script>";
    } else {
        echo "<script> alert('les donnees nest pas valide'); window.location ='$url'+'pageDirecteur.php?modele=ajouterpieces'; </script>";
    }
    
?>