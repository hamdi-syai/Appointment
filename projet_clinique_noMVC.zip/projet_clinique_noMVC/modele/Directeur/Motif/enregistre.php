<?php
    require_once "../../../../projet_clinique_NOMVC/connect.php";
    require_once "../../../../projet_clinique_noMVC/config.php";

    $motif = $_POST['libelleMotif'];
    $prix = $_POST['prixMotif'];
    $queryEnregistre = "Insert into motif(libelleMotif, prixMotif) values ('$motif', '$prix')";
    $resultat = $connection->query($queryEnregistre);
    $resultat->closeCursor();
    if ($resultat == true && !empty($motif) && !empty($prix)) {
        echo "<script> alert('Motif a ete enregistre'); window.location='$url'+'pageDirecteur.php?modele=listefourni';</script>";
    } else {
        echo "<script> alert('les donnees nest pas valide'); window.location ='$url'+'pageDirecteur.php?modele=ajouterMotif'; </script>";
    }
    
?>