<?php   

if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])) {
    echo "<center>Untuk mengakses modul, Anda harus login <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else { ?>

<style>
        .popup{
            animation: transitionIn-Y-bottom 0.5s;
        }
        .sub-table{
            animation: transitionIn-Y-bottom 0.5s;
        }
</style>

    <div>
        <div>
            <center>
            <table width="80%" border="0">
            <tr>
                <td class="label-td" colspan="2"></td>
            </tr>
                <tr>
                    <td>
                        <p style="padding: 0;margin: 0;text-align: left;font-size: 25px;font-weight: 500;">Modifier Personnel.</p><br><br>
                    </td>
                </tr>
                <tr>
                    <form action="modele/Directeur/Motif/modifier.php" method="post">
    
                        <?php
                        require_once "connect.php";
                        require_once "config.php";
                        $idMotif = $_GET['idMotif'];
                        $queryModif="SELECT * FROM motif where idMotif='$idMotif'";
                        $resultat=$connection->query($queryModif);
                        $resultat->setFetchMode(PDO::FETCH_OBJ);
                        while($ligne = $resultat->fetch()){
                        $idMotif = $ligne->idMotif;
                        $motif = $ligne->libelleMotif;
                        $prix = $ligne->prixMotif;
                        }
                        ?>


                    
                    <td class="label-td" colspan="2">
                    <input type="hidden" name="idMotif" value="<?php echo $idMotif; ?>">
                        <label for="name" class="form-label">Libelle Motif: </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <input type="text" name="libelleMotif" value="<?php echo $motif; ?>" class="input-text" required><br>
                                </td>
                                
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <label for="name" class="form-label">Prix Motif : </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                    <input type="text" name="prixMotif" value="<?php echo $prix; ?>" class="input-text" required><br>
                                </td>
                                
                </tr>
                <tr>
                    <td colspan="2">
                        <input type="submit" value="Enregistre" class="login-btn btn-primary btn">
                    </td>
                </tr>
            </form>
            </table>
            </center>
        </div>
    </div>

<?php } ?>