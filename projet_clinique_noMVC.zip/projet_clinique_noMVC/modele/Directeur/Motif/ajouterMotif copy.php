<?php   
 //session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
    echo "<center>Untuk mengakses modul, Anda harus login <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else { ?>
<style>
        .popup{
            animation: transitionIn-Y-bottom 0.5s;
        }
        .sub-table{
            animation: transitionIn-Y-bottom 0.5s;
        }
</style>
<div>
     <div>
        <center>
            <table width="80%" border="0">
            <tr>
                <td class="label-td" colspan="2"></td>
            </tr>
                <tr>
                    <td>
                        <p style="padding: 0;margin: 0;text-align: left;font-size: 25px;font-weight: 500;">Ajouter Motif.</p><br><br>
                    </td>
                </tr>
                <tr>
                    <form action="modele/Directeur/Motif/enregistre.php" method="post" class="add-new-form">
                    <td class="label-td" colspan="2">
                        <label for="name" class="form-label">Libelle Motif : </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <input type="text" name="libelleMotif" class="input-text" placeholder="Libelle Motif" required><br>
                                </td>
                                
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <label for="name" class="form-label">Prix Motif : </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                    <input type="text" name="prixMotif" class="input-text" placeholder="Prix Motif" required><br>
                                </td>
                                
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <label for="name" class="form-label">Consigne Motif : </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                    <select name="idConsigne" id="" class="box">
                                <?php
                                require_once "connect.php";
                                $queryConsigne = "SELECT * from consigne";
                                $resultat=$connection->query($queryConsigne);
                                $resultat->setFetchMode(PDO::FETCH_OBJ);
                                while($ligne = $resultat->fetch()){
                                ?>
                                    <option value="<?php echo $ligne->idConsigne; ?>"><?php echo $ligne->libelleConsigne; ?></option>
                                <?php } ?>
                    </select>
                    </td>  
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <label for="name" class="form-label">Liste Fourni : </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                    <select name="idPieces" id="" class="box">
                                <?php
                                require_once "connect.php";
                                $queryPieces = "SELECT * from pieces";
                                $resultat=$connection->query($queryPieces);
                                $resultat->setFetchMode(PDO::FETCH_OBJ);
                                while($ligne = $resultat->fetch()){
                                ?>
                                    <option value="<?php echo $ligne->idPieces; ?>"><?php echo $ligne->libellePieces; ?></option>
                                <?php } ?>
                    </select>
                    </td>  
                </tr>
                <tr>
                    <td colspan="2">
                        <input type="reset" value="Reset" class="login-btn btn-primary-soft btn" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    
                        <input type="submit" value="Enregistre" class="login-btn btn-primary btn">
                    </td>
                </tr>
                </form>
            </tr>
            </table>
        </center>
        <br><br>
     </div>
</div>
<?php } ?>
