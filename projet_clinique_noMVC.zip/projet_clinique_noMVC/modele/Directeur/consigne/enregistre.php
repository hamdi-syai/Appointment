<?php
    require_once "../../../../projet_clinique_NOMVC/connect.php";
    require_once "../../../../projet_clinique_noMVC/config.php";

    $consigne = $_POST['libelleConsigne'];
    $queryEnregistre = "Insert into consigne(libelleConsigne) values ('$consigne')";
    $resultat = $connection->query($queryEnregistre);
    $resultat->closeCursor();
    if ($resultat == true && !empty($consigne)) {
        echo "<script> alert('Consigne a ete enregistre'); window.location='$url'+'pageDirecteur.php?modele=listeconsigne';</script>";
    } else {
        echo "<script> alert('les donnees nest pas valide'); window.location ='$url'+'pageDirecteur.php?modele=ajouterconsigne'; </script>";
    }
    
?>