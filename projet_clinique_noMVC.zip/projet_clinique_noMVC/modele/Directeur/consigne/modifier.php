<?php
session_start();

if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
    echo "<center>Untuk mengakses modul, Anda harus login <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else {

    require_once "../../../../projet_clinique_noMVC/config.php";
    require_once "../../../../projet_clinique_noMVC/connect.php";
    $idConsigne = $_POST['idConsigne'];
    $consigne = $_POST['libelleConsigne'];
    //$prix = $_POST['prixMotif'];
    /* $user = $_POST['userPerson'];
    $mdp = $_POST['mdpPerson']; */
    //$idCat = $_POST['idCategorie'];
    //$idSpecialiste = $_POST['idSpecialiste'];
    $queryModif = "UPDATE consigne SET libelleConsigne='$consigne' WHERE idConsigne='$idConsigne'";
    $resultat = $connection->query($queryModif);
    $resultat->closeCursor();
    if ($resultat == true && !empty($_POST['libelleConsigne'])) {
        echo "<script> alert('consigne a ete modifie'); window.location='$url'+'pageDirecteur.php?modele=listeconsigne';</script>";
    } else {
        echo "<script> alert('les donnees nest pas valide'); window.location ='$url'+'pageDirecteur.php?modele=modifierconsigne&idConsigne='+''$idConsigne'; </script>";
    }
}
?>