<?php   
 //session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
    echo "<center>Untuk mengakses modul, Anda harus login <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else { ?>
<style>
        .popup{
            animation: transitionIn-Y-bottom 0.5s;
        }
        .sub-table{
            animation: transitionIn-Y-bottom 0.5s;
        }
</style>
<div>
     <div>
        <center>
            <table width="80%" border="0">
            <tr>
                <td class="label-td" colspan="2"></td>
            </tr>
                <tr>
                    <td>
                        <p style="padding: 0;margin: 0;text-align: left;font-size: 25px;font-weight: 500;">Ajouter Pieces</p><br><br>
                    </td>
                </tr>
                <tr>
                    <form action="modele/Directeur/consigne/enregistre.php" method="post" class="add-new-form">
                    <td class="label-td" colspan="2">
                        <label for="name" class="form-label">Libelle Consigne : </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <input type="text" name="libelleConsigne" class="input-text" placeholder="Libelle Consigne" required><br>
                                </td>
                                
                </tr>
                <tr>
                    <td colspan="2">
                        <input type="reset" value="Reset" class="login-btn btn-primary-soft btn" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    
                        <input type="submit" value="Enregistre" class="login-btn btn-primary btn">
                    </td>
                </tr>
                </form>
            </tr>
            </table>
        </center>
        <br><br>
     </div>
</div>
<?php } ?>
