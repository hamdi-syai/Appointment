<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
    echo "<center>Untuk mengakses modul, Anda harus login <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else {

    require_once "../../../../projet_clinique_noMVC/config.php";
    require_once "../../../../projet_clinique_noMVC/connect.php";

    $idPerson = $_GET['idPersonnel'];
    $querySupprimer = "DELETE FROM personnel WHERE idPersonnel='$idPerson'";
    $resultat=$connection->query($querySupprimer);
	$resultat->closeCursor();
    if ($resultat == true) {
        echo "<script> alert('Employeur est supprime'); window.location = '$url'+'pageDirecteur.php?modele=employeur';</script>";
    } else {
        echo "<script> alert('echec!'); window.location = '$url'+'pageDirecteur.php?modele=employeur';</script>";

    }
}
?>