<?php
    require_once "../../../../projet_clinique_NOMVC/connect.php";
    require_once "../../../../projet_clinique_noMVC/config.php";

    $nom = $_POST['nomPerson'];
    $prenom = $_POST['prenomPerson'];
    $user = $_POST['userPerson'];
    $mdp = $_POST['mdpPerson'];
    $idCat = $_POST['idCategorie'];
    $idSpecialiste = $_POST['idSpecialiste'];
    $queryEnregistre = "Insert into personnel(nomPersonnel, prenomPersonnel, username, password, idCategorie, idSpecialite) values ('$nom', '$prenom', '$user', '$mdp', '$idCat', '$idSpecialiste')";
    $resultat = $connection->query($queryEnregistre);
    $resultat->closeCursor();
    if ($resultat == true && !empty($_POST['nomPerson']) && !empty($_POST['prenomPerson']) && !empty($_POST['userPerson']) && !empty($_POST['mdpPerson']) && !empty($_POST['idCategorie']) && !empty($idSpecialiste)) {
        echo "<script> alert('Personnel a ete enregistre'); window.location='$url'+'pageDirecteur.php?modele=employeur';</script>";
    } else {
        echo "<script> alert('les donnees nest pas valide'); window.location ='$url'+'pageDirecteur.php?modele=ajouterPersonnel'; </script>";
    }
    
?>