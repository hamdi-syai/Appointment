<?php   

if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])) {
    echo "<center>Untuk mengakses modul, Anda harus login <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else { ?>

<style>
        .popup{
            animation: transitionIn-Y-bottom 0.5s;
        }
        .sub-table{
            animation: transitionIn-Y-bottom 0.5s;
        }
</style>

    <div>
        <div>
            <center>
            <table width="80%" border="0">
            <tr>
                <td class="label-td" colspan="2"></td>
            </tr>
                <tr>
                    <td>
                        <p style="padding: 0;margin: 0;text-align: left;font-size: 25px;font-weight: 500;">Modifier Personnel.</p><br><br>
                    </td>
                </tr>
                <tr>
                    <form action="modele/Directeur/employeur/modifier.php" method="post">
    
                        <?php
                        require_once "connect.php";
                        require_once "config.php";
                        $idPersonnel = $_GET['idPersonnel'];
                        $queryModif="SELECT * FROM personnel inner join categorie on personnel.idCategorie = categorie.idCategorie where idPersonnel='$idPersonnel'";
                        $resultat=$connection->query($queryModif);
                        $resultat->setFetchMode(PDO::FETCH_OBJ);
                        while($ligne = $resultat->fetch()){
                        $idPerson = $ligne->idPersonnel;
                        $nom = $ligne->nomPersonnel;
                        $prenom = $ligne->prenomPersonnel;
                        $userPerson = $ligne->username;
                        $mdpPerson = $ligne->password;
                        $categorie = $ligne->libelleCategorie;
                        }
                        ?>


                    
                    <td class="label-td" colspan="2">
                    <input type="hidden" name="idPerson" value="<?php echo $idPerson; ?>">
                        <label for="name" class="form-label">Nom Personnel: </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <input type="text" name="nomPerson" value="<?php echo $nom; ?>" class="input-text" required><br>
                                </td>
                                
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <label for="name" class="form-label">Prenom Personnel : </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                    <input type="text" name="prenomPerson" value="<?php echo $prenom; ?>" class="input-text" required><br>
                                </td>
                                
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <label for="name" class="form-label">Username : </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                    <input type="text" name="userPerson" value="<?php echo $userPerson; ?>" class="input-text" required><br>
                                </td>
                                
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                        <label for="name" class="form-label">Mot de pass : </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                    <input type="password" name="mdpPerson" value="<?php echo $mdpPerson; ?>" class="input-text" required><br>
                                </td>  
                </tr>
                <!-- <tr>
                    <td class="label-td" colspan="2">
                        <label for="name" class="form-label">Categorie : </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                    <select name="idCategorie" id="" class="box">
                                <?php
                                require_once "connect.php";
                                $queryCategorie = "SELECT * from categorie";
                                $resultat=$connection->query($queryCategorie);
                                $resultat->setFetchMode(PDO::FETCH_OBJ);
                                while($ligne = $resultat->fetch()){
                                ?>
                                    <option value="<?php echo $ligne->idCategorie; ?>"><?php echo $ligne->libelleCategorie; ?></option>
                                <?php } ?>
                    </select>
                    </td>  
                </tr> -->
                <tr>
                    <td class="label-td" colspan="2">
                        <label for="name" class="form-label">Specialiste : </label>
                    </td>
                </tr>
                <tr>
                    <td class="label-td" colspan="2">
                    <select name="idSpecialiste" id="" class="box">
                                <?php
                                require_once "connect.php";
                                $querySpecialite = "SELECT * from specialite order by idSpecialite desc";
                                $resultat=$connection->query($querySpecialite);
                                $resultat->setFetchMode(PDO::FETCH_OBJ);
                                while($ligne = $resultat->fetch()){
                                ?>
                                    <option value="<?php echo $ligne->idSpecialite; ?>"><?php echo $ligne->libelleSpecialite; ?></option>
                                <?php } ?>
                    </select>
                    </td>  
                </tr>
                <tr>
                    <td colspan="2">
                        <input type="submit" value="Enregistre" class="login-btn btn-primary btn">
                    </td>
                </tr>
            </form>
            </table>
            </center>
        </div>
    </div>

<?php } ?>