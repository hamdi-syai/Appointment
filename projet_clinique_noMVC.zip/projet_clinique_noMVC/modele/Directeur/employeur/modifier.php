<?php
session_start();

if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
    echo "<center>Untuk mengakses modul, Anda harus login <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else {

    require_once "../../../../projet_clinique_noMVC/config.php";
    require_once "../../../../projet_clinique_noMVC/connect.php";
    $idPerson = $_POST['idPerson'];
    $nom = $_POST['nomPerson'];
    $prenom = $_POST['prenomPerson'];
    $user = $_POST['userPerson'];
    $mdp = $_POST['mdpPerson'];
    //$idCat = $_POST['idCategorie'];
    $idSpecialiste = $_POST['idSpecialiste'];
    $queryModif = "UPDATE personnel SET nomPersonnel='$nom', prenomPersonnel='$prenom', username='$user', password='$mdp', /* idCategorie='$idCat', */ idSpecialite='$idSpecialiste' WHERE idPersonnel='$idPerson'";
    $resultat = $connection->query($queryModif);
    $resultat->closeCursor();
    if ($resultat == true && !empty($_POST['nomPerson']) && !empty($_POST['prenomPerson']) && !empty($_POST['userPerson']) && !empty($_POST['mdpPerson']) /* && !empty($_POST['idCategorie']) */) {
        //echo"<p>cek</p>";
        echo "<script> alert('Personnel a ete enregistre'); window.location='$url'+'pageDirecteur.php?modele=employeur';</script>";
    } else {
        echo "<script> alert('les donnees nest pas valide'); window.location ='$url'+'pageDirecteur.php?modele=modifierPersonnel&idPersonnel='+''$idPerson'; </script>";
    }
}
?>