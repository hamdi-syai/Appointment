<?php
    require_once "../../../../projet_clinique_NOMVC/connect.php";
    require_once "../../../../projet_clinique_noMVC/config.php";

    $specialite = $_POST['libellespecialite'];
    $queryEnregistre = "Insert into specialite(libelleSpecialite) values ('$specialite')";
    $resultat = $connection->query($queryEnregistre);
    $resultat->closeCursor();
    if ($resultat == true && !empty($specialite)) {
        echo "<script> alert('Specialite a ete enregistre'); window.location='$url'+'pageDirecteur.php?modele=listespecialite';</script>";
    } else {
        echo "<script> alert('les donnees nest pas valide'); window.location ='$url'+'pageDirecteur.php?modele=ajouterspecialite'; </script>";
    }
    
?>