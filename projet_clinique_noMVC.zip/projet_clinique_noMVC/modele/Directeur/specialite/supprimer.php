<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
    echo "<center>Untuk mengakses modul, Anda harus login <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else {

    require_once "../../../../projet_clinique_noMVC/config.php";
    require_once "../../../../projet_clinique_noMVC/connect.php";

    $idSpecialite = $_GET['idSpecialite'];
    $querySupprimer = "DELETE FROM specialite WHERE idSpecialite='$idSpecialite'";
    $resultat=$connection->query($querySupprimer);
	$resultat->closeCursor();
    if ($resultat == true) {
        echo "<script> alert('Consigne est supprime'); window.location = '$url'+'pageDirecteur.php?modele=listespecialite';</script>";
    } else {
        echo "<script> alert('echec!'); window.location = '$url'+'pageDirecteur.php?modele=listespecialite';</script>";

    }
}
?>