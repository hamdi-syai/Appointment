<?php   

if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
    echo "<center>Untuk mengakses modul, Anda harus login <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
} else { ?>

<thead>
        <tr>
            <th class="table-headin">Libelle Pieces </th>
            <th class="table-headin">Action</th>
        </tr>
</thead>
<tbody>
<tr>

<?php
if(isset($_POST["search"])){
    //$keyword=$_POST["search"];
    require_once "connect.php";
    $mainquery= "SELECT motif.libelleMotif, motif.prixMotif, pieces.libellePieces, consigne.libelleConsigne FROM pieces inner join piecesMotif on pieces.idPieces = piecesMotif.idPieces inner join motif on piecesMotif.idMotif = motif.idMotif inner join consignemotif on motif.idMotif = consignemotif.idMotif inner join consigne on consignemotif.idConsigne = consigne.idConsigne where motif.libelleMotif='$keyword' or motif.libelleMotif like '$keyword%' or motif.libelleMotif like '%$keyword' or motif.libelleMotif like '%$keyword%' ";
    $resultat=$connection->query($mainquery);
    $resultat->setFetchMode(PDO::FETCH_OBJ);
    $ligne=$resultat->fetch();
    if ($ligne == false) {?>
        <tr>
                                <td colspan="4">
                                <br><br><br><br>
                                <center>
                                <img src="img/notfound.svg" width="25%">
                                
                                <br>
                                <p class="heading-main12" style="margin-left: 45px;font-size:20px;color:rgb(49, 49, 49)">We  couldnt find anything related to your keywords !</p>
                                <a class="non-style-link" href="pageDirecteur.php?modele=employeur"><button  class="login-btn btn-primary-soft btn"  style="display: flex;justify-content: center;align-items: center;margin-left:20px;">&nbsp; Show all Patients &nbsp;</font></button>
                                </a>
                                </center>
                                <br><br><br><br>
                                </td>
                                </tr>';
    <?php 
    }else{
        for ($k=0; $k < $ligne; $k++) { ?>
            <tr>
            <td style="text-align:center;">&nbsp;<?php echo $ligne->libellePieces;?></td>
            <td>
                <div style="display:flex;justify-content: center;">
                <a href="pageDirecteur.php?modele=modifierPersonnel&idPersonnel=<?php echo $ligne->idPersonnel;?>" class="non-style-link"><button  class="btn-primary-soft btn button-icon btn-edit"  style="padding-left: 40px;padding-top: 12px;padding-bottom: 12px;margin-top: 10px;"><font class="tn-in-text">Modifier</font></button></a>
               &nbsp;&nbsp;&nbsp;
               <a href="modele/employeur/supprimer.php?idPersonnel=<?php echo $ligne->idPersonnel;?>" class="non-style-link"><button  class="btn-primary-soft btn button-icon btn-delete"  style="padding-left: 40px;padding-top: 12px;padding-bottom: 12px;margin-top: 10px;" onClick="return confirm('vous-etez sure de supprimer ?')"><font class="tn-in-text">Supprimer</font></button></a>
                </div>
            </td>
        </tr>
    <?php
        } }
    

}else{
        require_once "connect.php";
        $query="SELECT * FROM specialite";
		$resultat=$connection->query($query);
		$resultat->setFetchMode(PDO::FETCH_OBJ);
        while($ligne=$resultat->fetch()){
        ?>
        <tr>
            <td style="text-align:center;">&nbsp;<?php echo $ligne->libelleSpecialite;?></td>
             <!-- 
            <td style="text-align:center;">&nbsp;<?php //echo $ligne->libellePieces;?></td> -->
            <td>
                <div style="display:flex;justify-content: center;">
                <a href="pageDirecteur.php?modele=modifierspecialite&idSpecialite=<?php echo $ligne->idSpecialite;?>" class="non-style-link"><button  class="btn-primary-soft btn button-icon btn-edit"  style="padding-left: 40px;padding-top: 12px;padding-bottom: 12px;margin-top: 10px;"><font class="tn-in-text">Modifier</font></button></a>
               &nbsp;&nbsp;&nbsp;
               <a href="modele/Directeur/specialite/supprimer.php?idSpecialite=<?php echo $ligne->idSpecialite;?>" class="non-style-link"><button  class="btn-primary-soft btn button-icon btn-delete"  style="padding-left: 40px;padding-top: 12px;padding-bottom: 12px;margin-top: 10px;" onClick="return confirm('vous-etez sure de supprimer ?')"><font class="tn-in-text">Supprimer</font></button></a>
                </div>
            </td>
        </tr>
        
        
        <?php } ?>
        <tr >
           
            <td>&nbsp;&nbsp;&nbsp;</td>
                    <td style="padding-top:30px;">
                    <div style="display:flex;justify-content: center;">
                        <a href="pageDirecteur.php?modele=ajouterspecialite" class="non-style-link"><button  class="login-btn btn-primary btn button-icon"  style="margin-top: 10px; display: flex;justify-content: center;align-items: center;margin-left:85px;background-image: url('img/icons/add.svg');">Creer Specialite</font></button></a>
                    </div>
                    </td>
    </tr>
</tbody>
<?php } } ?>