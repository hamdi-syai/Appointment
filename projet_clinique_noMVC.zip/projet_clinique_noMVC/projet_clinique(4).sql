-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : jeu. 16 mars 2023 à 13:05
-- Version du serveur : 10.4.27-MariaDB
-- Version de PHP : 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `projet_clinique`
--

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE `categorie` (
  `idCategorie` int(3) NOT NULL,
  `libelleCategorie` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `categorie`
--

INSERT INTO `categorie` (`idCategorie`, `libelleCategorie`) VALUES
(1, 'Directeur'),
(2, 'Medecin'),
(3, 'Secretariat');

-- --------------------------------------------------------

--
-- Structure de la table `consigne`
--

CREATE TABLE `consigne` (
  `idConsigne` int(3) NOT NULL,
  `libelleConsigne` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `consigne`
--

INSERT INTO `consigne` (`idConsigne`, `libelleConsigne`) VALUES
(1, 'se laver à la bétadine une heure avant');

-- --------------------------------------------------------

--
-- Structure de la table `consignemotif`
--

CREATE TABLE `consignemotif` (
  `idMotif` int(3) DEFAULT NULL,
  `idConsigne` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `consignemotif`
--

INSERT INTO `consignemotif` (`idMotif`, `idConsigne`) VALUES
(3, 1);

-- --------------------------------------------------------

--
-- Structure de la table `motif`
--

CREATE TABLE `motif` (
  `idMotif` int(3) NOT NULL,
  `libelleMotif` text DEFAULT NULL,
  `prixMotif` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `motif`
--

INSERT INTO `motif` (`idMotif`, `libelleMotif`, `prixMotif`) VALUES
(1, 'Biopsie', '100.00'),
(2, 'Consultation', '40.00'),
(3, 'M1', '88.00'),
(4, 'M2', '60.00');

-- --------------------------------------------------------

--
-- Structure de la table `patient`
--

CREATE TABLE `patient` (
  `nss` varchar(15) NOT NULL,
  `nomPatient` varchar(50) DEFAULT NULL,
  `prenomPatient` varchar(50) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `numTel` int(10) DEFAULT NULL,
  `dateNais` date DEFAULT NULL,
  `departementNais` varchar(50) DEFAULT NULL,
  `solde` decimal(5,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `patient`
--

INSERT INTO `patient` (`nss`, `nomPatient`, `prenomPatient`, `adresse`, `numTel`, `dateNais`, `departementNais`, `solde`) VALUES
('111111111111111', 'P1', 'P1', '31 rue republique', 534532424, '2023-03-01', 'orleans', '0.01');

-- --------------------------------------------------------

--
-- Structure de la table `personnel`
--

CREATE TABLE `personnel` (
  `idPersonnel` int(3) NOT NULL,
  `nomPersonnel` varchar(50) DEFAULT NULL,
  `prenomPersonnel` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `idCategorie` int(3) DEFAULT NULL,
  `idSpecialite` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `personnel`
--

INSERT INTO `personnel` (`idPersonnel`, `nomPersonnel`, `prenomPersonnel`, `username`, `password`, `idCategorie`, `idSpecialite`) VALUES
(1, 'Hamdi', 'Syaibatul', 'hamdi007', 'hamdi001', 1, 57),
(2, 'ayvaz', 'sadettin', 'sadettin123', 'sadettin123', 3, 57),
(3, 'boulin', 'arnaud', 'arnaud123', 'arnaud123', 2, 47);

-- --------------------------------------------------------

--
-- Structure de la table `pieces`
--

CREATE TABLE `pieces` (
  `idPieces` int(3) NOT NULL,
  `libellePieces` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `pieces`
--

INSERT INTO `pieces` (`idPieces`, `libellePieces`) VALUES
(1, 'Carte vitale'),
(2, 'Pansement');

-- --------------------------------------------------------

--
-- Structure de la table `piecesmotif`
--

CREATE TABLE `piecesmotif` (
  `idMotif` int(3) DEFAULT NULL,
  `idPieces` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `piecesmotif`
--

INSERT INTO `piecesmotif` (`idMotif`, `idPieces`) VALUES
(3, 1),
(3, 2);

-- --------------------------------------------------------

--
-- Structure de la table `rdv`
--

CREATE TABLE `rdv` (
  `idRDV` int(10) NOT NULL,
  `dateRDV` datetime DEFAULT NULL,
  `etatRDV` text DEFAULT 'En attend de paiement',
  `nss` varchar(15) DEFAULT NULL,
  `idPersonnel` int(3) DEFAULT NULL,
  `idMotif` int(3) DEFAULT NULL,
  `idPieces` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `rdv`
--

INSERT INTO `rdv` (`idRDV`, `dateRDV`, `etatRDV`, `nss`, `idPersonnel`, `idMotif`, `idPieces`) VALUES
(7, '2023-03-17 10:00:00', 'paiement validé', '111111111111111', 3, 1, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `specialite`
--

CREATE TABLE `specialite` (
  `idSpecialite` int(3) NOT NULL,
  `libelleSpecialite` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `specialite`
--

INSERT INTO `specialite` (`idSpecialite`, `libelleSpecialite`) VALUES
(1, 'Accident and emergency medicine'),
(2, 'Allergology'),
(3, 'Anaesthetics'),
(4, 'Biological hematology'),
(5, 'Cardiology'),
(6, 'Child psychiatry'),
(7, 'Clinical biology'),
(8, 'Clinical chemistry'),
(9, 'Clinical neurophysiology'),
(10, 'Clinical radiology'),
(11, 'Dental, oral and maxillo-facial surgery'),
(12, 'Dermato-venerology'),
(13, 'Dermatology'),
(14, 'Endocrinology'),
(15, 'Gastro-enterologic surgery'),
(16, 'Gastroenterology'),
(17, 'General hematology'),
(18, 'General Practice'),
(19, 'General surgery'),
(20, 'Geriatrics'),
(21, 'Immunology'),
(22, 'Infectious diseases'),
(23, 'Internal medicine'),
(24, 'Laboratory medicine'),
(25, 'Maxillo-facial surgery'),
(26, 'Microbiology'),
(27, 'Nephrology'),
(28, 'Neuro-psychiatry'),
(29, 'Neurology'),
(30, 'Neurosurgery'),
(31, 'Nuclear medicine'),
(32, 'Obstetrics and gynecology'),
(33, 'Occupational medicine'),
(34, 'Ophthalmology'),
(35, 'Orthopaedics'),
(36, 'Otorhinolaryngology'),
(37, 'Paediatric surgery'),
(38, 'Paediatrics'),
(39, 'Pathology'),
(40, 'Pharmacology'),
(41, 'Physical medicine and rehabilitation'),
(42, 'Plastic surgery'),
(43, 'Podiatric Medicine'),
(44, 'Podiatric Surgery'),
(45, 'Psychiatry'),
(46, 'Public health and Preventive Medicine'),
(47, 'Radiology'),
(48, 'Radiotherapy'),
(49, 'Respiratory medicine'),
(50, 'Rheumatology'),
(51, 'Stomatology'),
(52, 'Thoracic surgery'),
(53, 'Tropical medicine'),
(54, 'Urology'),
(55, 'Vascular surgery'),
(56, 'Venereology'),
(57, '-');

-- --------------------------------------------------------

--
-- Structure de la table `tacheadmin`
--

CREATE TABLE `tacheadmin` (
  `idTache` int(10) NOT NULL,
  `dateTache` datetime DEFAULT NULL,
  `libelleTache` text DEFAULT NULL,
  `idpersonnel` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `tacheadmin`
--

INSERT INTO `tacheadmin` (`idTache`, `dateTache`, `libelleTache`, `idpersonnel`) VALUES
(1, '2023-03-18 12:00:00', 'Absence', 3);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `categorie`
--
ALTER TABLE `categorie`
  ADD PRIMARY KEY (`idCategorie`);

--
-- Index pour la table `consigne`
--
ALTER TABLE `consigne`
  ADD PRIMARY KEY (`idConsigne`);

--
-- Index pour la table `consignemotif`
--
ALTER TABLE `consignemotif`
  ADD KEY `idMotif` (`idMotif`),
  ADD KEY `idConsigne` (`idConsigne`);

--
-- Index pour la table `motif`
--
ALTER TABLE `motif`
  ADD PRIMARY KEY (`idMotif`);

--
-- Index pour la table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`nss`);

--
-- Index pour la table `personnel`
--
ALTER TABLE `personnel`
  ADD PRIMARY KEY (`idPersonnel`);

--
-- Index pour la table `pieces`
--
ALTER TABLE `pieces`
  ADD PRIMARY KEY (`idPieces`);

--
-- Index pour la table `piecesmotif`
--
ALTER TABLE `piecesmotif`
  ADD KEY `idMotif` (`idMotif`),
  ADD KEY `idPieces` (`idPieces`);

--
-- Index pour la table `rdv`
--
ALTER TABLE `rdv`
  ADD PRIMARY KEY (`idRDV`),
  ADD KEY `nss` (`nss`),
  ADD KEY `idPersonnel` (`idPersonnel`),
  ADD KEY `idMotif` (`idMotif`),
  ADD KEY `idPieces` (`idPieces`);

--
-- Index pour la table `specialite`
--
ALTER TABLE `specialite`
  ADD PRIMARY KEY (`idSpecialite`);

--
-- Index pour la table `tacheadmin`
--
ALTER TABLE `tacheadmin`
  ADD PRIMARY KEY (`idTache`),
  ADD KEY `idPersonnel` (`idpersonnel`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `consigne`
--
ALTER TABLE `consigne`
  MODIFY `idConsigne` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `motif`
--
ALTER TABLE `motif`
  MODIFY `idMotif` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `personnel`
--
ALTER TABLE `personnel`
  MODIFY `idPersonnel` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `pieces`
--
ALTER TABLE `pieces`
  MODIFY `idPieces` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `rdv`
--
ALTER TABLE `rdv`
  MODIFY `idRDV` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `specialite`
--
ALTER TABLE `specialite`
  MODIFY `idSpecialite` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT pour la table `tacheadmin`
--
ALTER TABLE `tacheadmin`
  MODIFY `idTache` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `consignemotif`
--
ALTER TABLE `consignemotif`
  ADD CONSTRAINT `consignemotif_ibfk_1` FOREIGN KEY (`idMotif`) REFERENCES `motif` (`idMotif`),
  ADD CONSTRAINT `consignemotif_ibfk_2` FOREIGN KEY (`idConsigne`) REFERENCES `consigne` (`idConsigne`);

--
-- Contraintes pour la table `piecesmotif`
--
ALTER TABLE `piecesmotif`
  ADD CONSTRAINT `idMotif` FOREIGN KEY (`idMotif`) REFERENCES `motif` (`idMotif`),
  ADD CONSTRAINT `idPieces` FOREIGN KEY (`idPieces`) REFERENCES `pieces` (`idPieces`);

--
-- Contraintes pour la table `tacheadmin`
--
ALTER TABLE `tacheadmin`
  ADD CONSTRAINT `idPersonnel` FOREIGN KEY (`idpersonnel`) REFERENCES `personnel` (`idPersonnel`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
