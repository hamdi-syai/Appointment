<?php
require_once "connect.php";

$username = $_POST['userlogin'];
$password = $_POST['mdplogin'];
//$idCat = $_POST['categorieLogin'];

if (!ctype_alnum($username) OR !ctype_alnum($password)) {
    echo "<center>LOGIN FAILED!!<br> Username or Password not corrext.<br> or your account is blocked.<br>";
                    echo "<a href=index.php><b>TRY AGAIN</b></a></center>";
} else {

    session_start();

    $_SESSION["username"]="";
    $_SESSION["idCategorie"]="";
    
    // Set the new timezone
    //date_default_timezone_set('Europe/France');
    $date = date('Y-m-d');

    $_SESSION["date"]=$date;

    if($_POST){

        $username = $_POST['userlogin'];
        $password = $_POST['mdplogin'];

        $result= $connection->query("select * from personnel where username='$username' and password='$password'");
        $row = $result->fetch(PDO::FETCH_ASSOC);
        if($row==true){
            
            $categorie = $row['idCategorie'];
            //$categorie=$result->fetch_assoc()['idCategorie'];
            if ($categorie==1){
                $checker = $connection->query("select * from personnel where username='$username' and password='$password'");
                if ($checker==true){

                    //   Directeur dashbord
                    $_SESSION['username']=$username;
                    $_SESSION['idCategorie']='1';
                    
                    header("location:pageDirecteur.php");

                }else{
                    echo "<center>LOGIN FAILED!!<br> Username or Password not corrext.<br> or your account is blocked.<br>";
                    echo "<a href=index.php><b>TRY AGAIN</b></a></center>";
                }

            }elseif($categorie==2){
                $checker = $connection->query("select * from personnel where username='$username' and password='$password'");
                if ($checker==true){


                    //   Admin dashbord
                    $_SESSION['username']=$username;
                    $_SESSION['idCategorie']='2';
                    
                    header("location:pageMedecin.php");


                }else{
                    echo "<center>LOGIN FAILED!!<br> Username or Password not corrext.<br> or your account is blocked.<br>";
                    echo "<a href=index.php><b>TRY AGAIN</b></a></center>";
                }

            }elseif($categorie==3){
                $checker = $connection->query("select * from personnel where username='$username' and password='$password'");
                if ($checker==true){


                    //   doctor dashbord
                    $_SESSION['username']=$username;
                    $_SESSION['idCategorie']='3';
                    
                    header("location:pageAdmin.php");


                }else{
                    echo "<center>LOGIN FAILED!!<br> Username or Password not corrext.<br> or your account is blocked.<br>";
                    echo "<a href=index.php><b>TRY AGAIN</b></a></center>";
                }

            }
            
        }else{
            echo "<center>LOGIN FAILED!!<br> Username or Password not corrext.<br> or your account is blocked.<br>";
                    echo "<a href=index.php><b>TRY AGAIN</b></a></center>";
        }

        
    }else{
        echo "<center>LOGIN FAILED!!<br> Username or Password not corrext.<br> or your account is blocked.<br>";
                    echo "<a href=index.php><b>TRY AGAIN</b></a></center>";
    }


}