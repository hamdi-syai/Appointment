function nbSession() {
    let table = document.getElementById("f3");
  
    // Get the value of the first input field
    let x = document.forms["f1"].elements["idmed"].value;
    let y = document.forms["f1"].elements["nommedecin"].value;
  
    // Get the number of sessions
    let numSessions = parseInt(document.forms["f1"].elements["session"].value);
  
    // Create a new row for each session
    for (let i = 0; i < numSessions; i++) {
      // Create a new row element
      let row = document.createElement("tr");

      // Create a new cell for the first input
      let cell1 = document.createElement("td");
  
      // Create the first input element and set its attributes and value
      let input1 = document.createElement("input");
      input1.setAttribute("type", "text");
      input1.setAttribute("class", "input-text");
      input1.setAttribute("style", "text-align:center;");
      input1.setAttribute("name", "idmed"+i);
      input1.setAttribute("value", x);
      input1.setAttribute("readonly", true);
  
      // Add the first input element to the first cell
      cell1.appendChild(input1);

      // Create a new cell for the first input
      let cell2 = document.createElement("td");
  
      // Create the first input element and set its attributes and value
      let input2 = document.createElement("input");
      input2.setAttribute("type", "text");
      input2.setAttribute("class", "input-text");
      input2.setAttribute("style", "text-align:center;");
      input2.setAttribute("name", "nommedecin"+i);
      input2.setAttribute("value", y);
      input2.setAttribute("readonly", true);
  
      // Add the first input element to the first cell
      cell2.appendChild(input2);
  
      // Create a new cell for the second input
      let cell3 = document.createElement("td");
  
      // Create the second input element and set its attributes
      let input3 = document.createElement("input");
      input3.setAttribute("type", "datetime-local");
      input3.setAttribute("class", "input-text");
      input3.setAttribute("name", "daterdv"+i);
      input3.setAttribute("step", "3600");
      input3.setAttribute("style", "text-align:center;");

      // Add the second input element to the second cell
      cell3.appendChild(input3);
  
      // Add the two cells to the row element
      row.appendChild(cell1);
      row.appendChild(cell2);
      row.appendChild(cell3);
  
      // Add the row to the table
      table.appendChild(row);

    }
  }