<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/animations.css">  
    <link rel="stylesheet" href="css/main.css"> 
    <link rel="stylesheet" href="css/login.css">
    <title>Projet Clinique sans MVC</title>
</head>
<body>
    <center>
    <div class="container">
        <div class="bienvenue">Bienvenue à la gestion des patients de la clinique S.A.H</div>
        <table border="0" style="margin: 0;padding: 0;width: 60%;">
        <div class="form-body">
            <tr>
                <td>
                    <p class="sub-text">Login with your details to continue</p>
                </td>
            </tr>
            <tr>
            <form action="login.php" method="post">
                    <td class="label-td"><label class="form-label">Username : </label><input type="text" class="input-text" name="userlogin"></td>
            </tr>
            <tr>
                    <td class="label-td"><label class="form-label">Password : </label><input type="password" class="input-text" name="mdplogin"></td>
            </tr>
            <tr>
                    <td><input type="submit" name="connect" class="login-btn btn-primary btn" Value="Sign In"></td>
            </tr>
            </form>
        </div>
        </table>
    </div>
    </center>
</body>
</html>