<?php
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
require_once "connect.php";
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['password'])) {
    echo "<center>Untuk mengakses modul, Anda harus login <br>";
    //echo "<a href=$admin_url><b>LOGIN</b></a></center>";
} else { ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="css/mobiscroll.javascript.min.css" rel="stylesheet" />
	<script src="js/mobiscroll.javascript.min.js"></script>
	<title>Page Secretariat</title>
</head>
<body>
    <header>
    	<nav>
    		<ul>
    			<li> <a href="pageAdmin.php?modele=patient" name="menu">Gestion Patient</a> </li>
    			<li> <a href="pageAdmin.php?modele=specialite" name="rdv">Gestion RDV</a> </li>
    
    
    			<!-- <li> <a href="pageDirecteur.php?modele=consulterfichepatient" name="consulte">Consulter fiche patient</a> </li> -->
    		</ul>
    	</nav>
    </header>
<?php } ?>